import SwiftUI

@main
struct TeleprompterApp: App {
    @StateObject private var scriptStore = ScriptStore()
    @StateObject private var settings = TeleprompterSettings()
    @StateObject private var cameraManager = CameraRecordingManager()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(scriptStore)
                .environmentObject(settings)
                .environmentObject(cameraManager)
                .preferredColorScheme(settings.isLightMode ? .light : .dark)
                .tint(settings.theme.accentTint)
        }
    }
}
