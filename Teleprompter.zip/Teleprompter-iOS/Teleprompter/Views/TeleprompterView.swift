import SwiftUI

struct TeleprompterView: View {
    let script: ScriptItem
    @EnvironmentObject var settings: TeleprompterSettings
    @EnvironmentObject var cameraManager: CameraRecordingManager
    @Environment(\.dismiss) private var dismiss

    @StateObject private var voiceEngine = VoiceTrackEngine()

    @State private var isPlaying: Bool = false
    @State private var countdownRemaining: Int = 0
    @State private var scrollOffset: CGFloat = 0.0
    @State private var activeParagraphIndex: Int = 0
    @State private var elapsedSeconds: Int = 0
    @State private var showControlsHUD: Bool = true

    private let frameTimer = Timer.publish(every: 1.0 / 60.0, on: .main, in: .common).autoconnect()
    private let secondTimer = Timer.publish(every: 1.0, on: .main, in: .common).autoconnect()

    var paragraphs: [String] {
        script.paragraphs
    }

    var body: some View {
        let isLight = settings.isLightMode && !(settings.showCameraPreview && settings.fullScreenCameraStage)
        let fg = isLight ? PrompterTheme.softInkColor : PrompterTheme.warmPaperColor
        let bg = isLight ? PrompterTheme.warmPaperColor : PrompterTheme.softInkColor

        GeometryReader { geo in
            ZStack {
                if settings.showCameraPreview && settings.fullScreenCameraStage {
                    CameraPreviewRepresentable(session: cameraManager.session)
                        .ignoresSafeArea()
                    PrompterTheme.softInkColor.opacity(0.55)
                        .ignoresSafeArea()
                } else {
                    bg.ignoresSafeArea()
                }

                ScrollViewReader { proxy in
                    ScrollView(.vertical, showsIndicators: false) {
                        VStack(alignment: .leading, spacing: settings.lineSpacing + 14) {
                            Spacer()
                                .frame(height: geo.size.height * settings.eyeLineVerticalRatio)

                            ForEach(Array(paragraphs.enumerated()), id: \.offset) { index, line in
                                paragraphRow(index: index, text: line, fg: fg)
                                    .id(index)
                                    .onTapGesture {
                                        withAnimation(.easeInOut(duration: 0.25)) {
                                            activeParagraphIndex = index
                                            proxy.scrollTo(index, anchor: UnitPoint(x: 0.5, y: settings.eyeLineVerticalRatio))
                                        }
                                    }
                            }

                            Spacer()
                                .frame(height: geo.size.height * 0.72)
                        }
                        .padding(.horizontal, settings.horizontalMargin)
                        .offset(y: (settings.scrollMode == .continuous || settings.scrollMode == .voiceLevel) ? -scrollOffset : 0)
                    }
                    .contentShape(Rectangle())
                    .onTapGesture(count: 2) {
                        togglePlayPause()
                    }
                    .onTapGesture(count: 1) {
                        withAnimation(.spring(response: 0.28, dampingFraction: 0.8)) {
                            showControlsHUD.toggle()
                        }
                    }
                    .scaleEffect(
                        x: settings.mirrorHorizontal ? -1.0 : 1.0,
                        y: settings.mirrorVertical ? -1.0 : 1.0
                    )
                    .onChange(of: voiceEngine.matchedParagraphIndex) { newIdx in
                        guard settings.scrollMode == .voiceActivated else { return }
                        withAnimation(.easeInOut(duration: 0.35)) {
                            activeParagraphIndex = newIdx
                            proxy.scrollTo(newIdx, anchor: UnitPoint(x: 0.5, y: settings.eyeLineVerticalRatio))
                        }
                    }
                }

                if settings.showEyeLineGuide {
                    eyeLineOverlay(in: geo, fg: fg)
                }

                VStack {
                    topStudioBar(fg: fg, bg: bg)
                    Spacer()
                    if showControlsHUD {
                        bottomControlDeck(fg: fg, bg: bg)
                            .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                }
                .padding(14)

                if countdownRemaining > 0 {
                    ZStack {
                        bg.opacity(0.84).ignoresSafeArea()
                        VStack(spacing: 12) {
                            Text("\(countdownRemaining)")
                                .font(.system(size: 110, weight: .bold, design: .rounded))
                                .foregroundColor(fg)
                            Text("Keep your eyes near the camera lens")
                                .font(.headline)
                                .foregroundColor(fg.opacity(0.75))
                        }
                    }
                }
            }
        }
        .statusBar(hidden: true)
        .onAppear {
            UIApplication.shared.isIdleTimerDisabled = true
            settings.wordsPerMinute = Double(script.targetWPM)
            if settings.showCameraPreview {
                cameraManager.configureIfNeeded()
            }
        }
        .onDisappear {
            UIApplication.shared.isIdleTimerDisabled = false
            voiceEngine.stop()
        }
        .onReceive(frameTimer) { _ in
            guard isPlaying && countdownRemaining == 0 else { return }
            let pixelsPerSecond = CGFloat(settings.wordsPerMinute) * CGFloat(settings.fontSize) * 0.0145
            if settings.scrollMode == .continuous {
                scrollOffset += pixelsPerSecond / 60.0
            } else if settings.scrollMode == .voiceLevel && voiceEngine.isSpeakingNow {
                scrollOffset += (pixelsPerSecond * 1.15) / 60.0
            }
        }
        .onReceive(secondTimer) { _ in
            if countdownRemaining > 0 {
                countdownRemaining -= 1
                if countdownRemaining == 0 {
                    startActiveScrolling()
                }
            } else if isPlaying {
                elapsedSeconds += 1
            }
        }
        .sheet(isPresented: $cameraManager.showPostCaptureEditor) {
            VideoClipEditorView()
                .environmentObject(cameraManager)
                .environmentObject(settings)
        }
    }

    @ViewBuilder
    private func paragraphRow(index: Int, text: String, fg: Color) -> some View {
        let isCueOnly = text.hasPrefix("[") && text.hasSuffix("]")
        let isFocused = !settings.focusDimmingEnabled || abs(index - activeParagraphIndex) <= 1 || settings.scrollMode == .continuous

        if isCueOnly && settings.renderCueBadges {
            HStack(spacing: 8) {
                Image(systemName: "waveform")
                    .font(.system(size: 14, weight: .light))
                Text(text.replacingOccurrences(of: "[", with: "").replacingOccurrences(of: "]", with: ""))
                    .font(.system(size: max(16, settings.fontSize * 0.45), weight: .semibold, design: .rounded))
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 6)
            .background(fg.opacity(0.14))
            .foregroundColor(fg)
            .clipShape(Capsule())
        } else {
            Text(cleanDisplayLine(text))
                .font(.system(
                    size: settings.fontSize,
                    weight: (text.contains("[EMPHASIS]") || settings.easyReadEnabled) ? .bold : .semibold,
                    design: settings.fontDesign.swiftUIFontDesign
                ))
                .foregroundColor(fg.opacity(isFocused ? 1.0 : 0.32))
                .lineSpacing(settings.lineSpacing)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private func cleanDisplayLine(_ raw: String) -> String {
        raw.replacingOccurrences(of: "[EMPHASIS]", with: "")
           .trimmingCharacters(in: .whitespaces)
    }

    private func eyeLineOverlay(in geo: GeometryProxy, fg: Color) -> some View {
        let yPos = geo.size.height * settings.eyeLineVerticalRatio
        return ZStack {
            Rectangle()
                .fill(fg.opacity(0.08))
                .frame(height: settings.fontSize * 2.1)
                .overlay(
                    HStack {
                        Image(systemName: "chevron.right")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(fg)
                            .padding(.leading, 8)
                        Spacer()
                        Image(systemName: "chevron.left")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(fg)
                            .padding(.trailing, 8)
                    }
                )
                .position(x: geo.size.width / 2, y: yPos)
        }
        .allowsHitTesting(false)
    }

    private func topStudioBar(fg: Color, bg: Color) -> some View {
        HStack(spacing: 10) {
            Button {
                dismiss()
            } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 15, weight: .light))
                    .foregroundColor(fg)
                    .frame(width: 34, height: 34)
                    .background(bg.opacity(0.82))
                    .clipShape(Circle())
                    .overlay(Circle().stroke(fg.opacity(0.2), lineWidth: 1))
            }

            if settings.showElapsedTimer {
                HStack(spacing: 6) {
                    Circle()
                        .fill(isPlaying ? fg : fg.opacity(0.35))
                        .frame(width: 7, height: 7)
                    Text(String(format: "%02d:%02d", elapsedSeconds / 60, elapsedSeconds % 60))
                        .font(.system(.subheadline, design: .monospaced).weight(.semibold))
                        .foregroundColor(fg)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(bg.opacity(0.82))
                .clipShape(Capsule())
                .overlay(Capsule().stroke(fg.opacity(0.18), lineWidth: 1))
            }

            if settings.showCameraPreview {
                HStack(spacing: 6) {
                    Button {
                        cameraManager.setCamera(front: true)
                    } label: {
                        Text("Front")
                            .font(.caption2.weight(.semibold))
                            .padding(.horizontal, 9)
                            .padding(.vertical, 5)
                            .background(cameraManager.usingFrontCamera ? fg : bg.opacity(0.75))
                            .foregroundColor(cameraManager.usingFrontCamera ? bg : fg)
                            .clipShape(Capsule())
                    }

                    Button {
                        cameraManager.setCamera(front: false)
                    } label: {
                        Text("Back")
                            .font(.caption2.weight(.semibold))
                            .padding(.horizontal, 9)
                            .padding(.vertical, 5)
                            .background(!cameraManager.usingFrontCamera ? fg : bg.opacity(0.75))
                            .foregroundColor(!cameraManager.usingFrontCamera ? bg : fg)
                            .clipShape(Capsule())
                    }

                    Button {
                        withAnimation(.spring()) {
                            settings.fullScreenCameraStage.toggle()
                        }
                    } label: {
                        Text(settings.fullScreenCameraStage ? "Small Cam" : "Full Cam")
                            .font(.caption2.weight(.semibold))
                            .padding(.horizontal, 9)
                            .padding(.vertical, 5)
                            .background(bg.opacity(0.75))
                            .foregroundColor(fg)
                            .clipShape(Capsule())
                    }
                }
            }

            Spacer()

            Button {
                settings.toggleAppearanceMode()
            } label: {
                Image(systemName: settings.isLightMode ? "moon" : "sun.max")
                    .font(.system(size: 14, weight: .light))
                    .foregroundColor(fg)
                    .frame(width: 32, height: 32)
                    .background(bg.opacity(0.82))
                    .clipShape(Circle())
                    .overlay(Circle().stroke(fg.opacity(0.2), lineWidth: 1))
            }

            Button {
                cameraManager.showPostCaptureEditor = true
            } label: {
                HStack(spacing: 4) {
                    Image(systemName: "scissors")
                        .font(.system(size: 12, weight: .light))
                    Text("Edit Video")
                        .font(.caption2.weight(.semibold))
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(bg.opacity(0.82))
                .foregroundColor(fg)
                .clipShape(Capsule())
                .overlay(Capsule().stroke(fg.opacity(0.18), lineWidth: 1))
            }

            if settings.showCameraPreview && !settings.fullScreenCameraStage {
                ZStack(alignment: .bottomTrailing) {
                    CameraPreviewRepresentable(session: cameraManager.session)
                        .frame(width: 136, height: 88)
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .stroke(fg.opacity(0.65), lineWidth: 1.5)
                        )

                    Button {
                        cameraManager.toggleRecording()
                    } label: {
                        Image(systemName: cameraManager.isRecording ? "stop.circle.fill" : "record.circle")
                            .font(.title3)
                            .foregroundColor(PrompterTheme.warmPaperColor)
                            .padding(5)
                            .background(PrompterTheme.softInkColor.opacity(0.72))
                            .clipShape(Circle())
                            .padding(4)
                    }
                }
            }
        }
    }

    private func bottomControlDeck(fg: Color, bg: Color) -> some View {
        VStack(spacing: 12) {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(ScrollMode.allCases) { mode in
                        let isSelected = (settings.scrollMode == mode)
                        Button {
                            withAnimation(.spring(response: 0.28, dampingFraction: 0.78)) {
                                settings.scrollMode = mode
                                if isPlaying {
                                    configureVoiceIfNeeded()
                                }
                            }
                        } label: {
                            HStack(spacing: 6) {
                                Image(systemName: mode.icon)
                                    .font(.system(size: 12, weight: .light))
                                Text(mode.rawValue)
                                    .font(.caption.weight(.semibold))
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(
                                Capsule()
                                    .fill(isSelected ? fg : fg.opacity(0.08))
                            )
                            .foregroundColor(isSelected ? bg : fg)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }

            HStack(spacing: 22) {
                Button {
                    withAnimation(.spring()) {
                        scrollOffset = 0
                        activeParagraphIndex = 0
                        elapsedSeconds = 0
                    }
                } label: {
                    VStack(spacing: 2) {
                        Image(systemName: "backward.end")
                            .font(.system(size: 18, weight: .light))
                        Text("Restart")
                            .font(.caption2)
                    }
                    .foregroundColor(fg)
                }

                Button {
                    togglePlayPause()
                } label: {
                    Image(systemName: isPlaying ? "pause.circle.fill" : "play.circle.fill")
                        .font(.system(size: 52))
                        .foregroundColor(fg)
                }

                Button {
                    withAnimation(.spring()) {
                        settings.mirrorHorizontal.toggle()
                    }
                } label: {
                    VStack(spacing: 2) {
                        Image(systemName: "arrow.left.and.right.righttriangle.left.righttriangle.right")
                            .font(.system(size: 16, weight: .light))
                        Text("Flip L-R")
                            .font(.caption2)
                    }
                    .foregroundColor(settings.mirrorHorizontal ? fg : fg.opacity(0.6))
                }

                Button {
                    withAnimation(.spring()) {
                        settings.mirrorVertical.toggle()
                    }
                } label: {
                    VStack(spacing: 2) {
                        Image(systemName: "arrow.up.and.down.righttriangle.up.righttriangle.down")
                            .font(.system(size: 16, weight: .light))
                        Text("Flip U-D")
                            .font(.caption2)
                    }
                    .foregroundColor(settings.mirrorVertical ? fg : fg.opacity(0.6))
                }

                Button {
                    withAnimation(.spring()) {
                        settings.showCameraPreview.toggle()
                        if settings.showCameraPreview {
                            cameraManager.configureIfNeeded()
                        }
                    }
                } label: {
                    VStack(spacing: 2) {
                        Image(systemName: settings.showCameraPreview ? "video" : "video.slash")
                            .font(.system(size: 16, weight: .light))
                        Text("Camera")
                            .font(.caption2)
                    }
                    .foregroundColor(settings.showCameraPreview ? fg : fg.opacity(0.6))
                }
            }

            HStack(spacing: 16) {
                HStack(spacing: 8) {
                    Image(systemName: "speedometer")
                        .font(.system(size: 12, weight: .light))
                        .foregroundColor(fg)
                    Slider(value: $settings.wordsPerMinute, in: 60...260, step: 5)
                        .tint(fg)
                    Text("\(Int(settings.wordsPerMinute)) WPM")
                        .font(.caption.monospacedDigit().weight(.semibold))
                        .frame(width: 66, alignment: .trailing)
                }

                HStack(spacing: 8) {
                    Image(systemName: "textformat.size")
                        .font(.system(size: 12, weight: .light))
                        .foregroundColor(fg)
                    Slider(value: $settings.fontSize, in: 22...76, step: 2)
                        .tint(fg)
                    Text("\(Int(settings.fontSize))pt")
                        .font(.caption.monospacedDigit().weight(.semibold))
                        .frame(width: 42, alignment: .trailing)
                }
            }
            .foregroundColor(fg)
        }
        .padding(16)
        .background(bg.opacity(0.90))
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .stroke(fg.opacity(0.22), lineWidth: 1)
        )
    }

    private func togglePlayPause() {
        if isPlaying {
            isPlaying = false
            voiceEngine.stop()
        } else {
            if scrollOffset == 0 && settings.countdownSeconds > 0 {
                countdownRemaining = settings.countdownSeconds
            } else {
                startActiveScrolling()
            }
        }
    }

    private func startActiveScrolling() {
        isPlaying = true
        configureVoiceIfNeeded()
    }

    private func configureVoiceIfNeeded() {
        if settings.scrollMode == .voiceActivated || settings.scrollMode == .voiceLevel {
            voiceEngine.requestPermissionsAndStart(paragraphs: paragraphs)
        } else {
            voiceEngine.stop()
        }
    }
}
