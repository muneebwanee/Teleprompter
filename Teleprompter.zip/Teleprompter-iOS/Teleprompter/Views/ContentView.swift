import SwiftUI
import WidgetKit

struct ContentView: View {
    @EnvironmentObject var scriptStore: ScriptStore
    @EnvironmentObject var settings: TeleprompterSettings
    @EnvironmentObject var cameraManager: CameraRecordingManager

    @State private var searchText: String = ""
    @State private var selectedCategory: String = "All"
    @State private var isPresentingPrompter: Bool = false
    @State private var isShowingCameraStudio: Bool = false
    @State private var isShowingSettingsSheet: Bool = false

    private let categories = ["All", "Keynote", "Video", "Update", "Podcast"]

    var filteredScripts: [ScriptItem] {
        scriptStore.scripts.filter { item in
            let matchesCategory = (selectedCategory == "All") || (item.category == selectedCategory)
            let matchesSearch = searchText.isEmpty ||
                item.title.localizedCaseInsensitiveContains(searchText) ||
                item.content.localizedCaseInsensitiveContains(searchText)
            return matchesCategory && matchesSearch
        }
    }

    var body: some View {
        let isLight = settings.isLightMode
        let fg = settings.primaryForeground
        let bg = settings.primaryBackground

        ZStack {
            bg.ignoresSafeArea()

            NavigationSplitView {
                sidebarList
                    .navigationSplitViewColumnWidth(min: 300, ideal: 330, max: 380)
            } detail: {
                if let script = scriptStore.selectedScript {
                    ScriptEditorView(
                        script: Binding(
                            get: { script },
                            set: {
                                scriptStore.selectedScript = $0
                                syncActiveScriptToHomeScreenWidgets($0)
                            }
                        ),
                        onStartPrompter: { isPresentingPrompter = true },
                        onOpenCameraStudio: { isShowingCameraStudio = true },
                        onOpenSettings: { isShowingSettingsSheet = true }
                    )
                } else {
                    emptyDetailPlaceholder
                }
            }
            .tint(fg)
        }
        .preferredColorScheme(isLight ? .light : .dark)
        .onAppear {
            if let s = scriptStore.selectedScript {
                syncActiveScriptToHomeScreenWidgets(s)
            }
        }
        .onOpenURL { url in
            let host = url.host ?? ""
            if host == "read" {
                isPresentingPrompter = true
            } else if host == "camera" {
                if url.query?.contains("lens=back") == true {
                    cameraManager.setCamera(front: false)
                } else {
                    cameraManager.setCamera(front: true)
                }
                isShowingCameraStudio = true
            } else if host == "voiceglide" {
                settings.scrollMode = .voiceActivated
                isPresentingPrompter = true
            } else if host == "new" {
                _ = scriptStore.createScript()
            }
        }
        .fullScreenCover(isPresented: $isPresentingPrompter) {
            if let script = scriptStore.selectedScript {
                TeleprompterView(script: script)
                    .environmentObject(settings)
                    .environmentObject(cameraManager)
            }
        }
        .fullScreenCover(isPresented: $isShowingCameraStudio) {
            if let script = scriptStore.selectedScript {
                BroadcastCameraView(script: script)
                    .environmentObject(settings)
                    .environmentObject(cameraManager)
            }
        }
        .sheet(isPresented: $isShowingSettingsSheet) {
            SettingsDrawerView()
                .environmentObject(settings)
        }
        .sheet(isPresented: $cameraManager.showPostCaptureEditor) {
            VideoClipEditorView()
                .environmentObject(cameraManager)
                .environmentObject(settings)
        }
    }

    private func syncActiveScriptToHomeScreenWidgets(_ script: ScriptItem) {
        let defaults = UserDefaults(suiteName: "group.com.muneebwanee.teleprompter") ?? .standard
        defaults.set(script.title, forKey: "widget_script_title")
        defaults.set(script.content, forKey: "widget_script_excerpt")
        defaults.set(script.wordCount, forKey: "widget_word_count")
        defaults.set(script.formattedDuration, forKey: "widget_duration")
        defaults.set(script.targetWPM, forKey: "widget_wpm")
        WidgetCenter.shared.reloadAllTimelines()
    }

    private var sidebarList: some View {
        let isLight = settings.isLightMode
        let fg = settings.primaryForeground
        let bg = settings.primaryBackground

        return VStack(spacing: 12) {
            VStack(alignment: .leading) {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Reading Studio")
                            .font(.caption.weight(.semibold))
                            .foregroundColor(fg)
                        Text("\(scriptStore.scripts.count) Scripts • \(Int(settings.wordsPerMinute)) WPM")
                            .font(.caption2)
                            .foregroundColor(fg.opacity(0.65))
                    }
                    Spacer()
                    Button {
                        isShowingCameraStudio = true
                    } label: {
                        Label("Camera", systemImage: "camera")
                            .font(.caption.weight(.semibold))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(fg)
                            .foregroundColor(bg)
                            .clipShape(Capsule())
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 12)
            }
            .liquidGlass(cornerRadius: 18, isHighlighted: false)
            .padding(.horizontal, 14)
            .padding(.top, 6)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(categories, id: \.self) { cat in
                        let active = (selectedCategory == cat)
                        Button {
                            withAnimation(.spring(response: 0.28, dampingFraction: 0.78)) {
                                selectedCategory = cat
                            }
                        } label: {
                            Text(cat)
                                .font(.caption.weight(.semibold))
                                .padding(.horizontal, 13)
                                .padding(.vertical, 7)
                                .background(
                                    Capsule()
                                        .fill(active ? fg : fg.opacity(0.06))
                                )
                                .foregroundColor(active ? bg : fg.opacity(0.70))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 16)
            }

            ScrollView {
                LazyVStack(spacing: 10) {
                    ForEach(filteredScripts) { item in
                        let isSelected = (scriptStore.selectedScriptID == item.id)
                        Button {
                            withAnimation(.spring(response: 0.28, dampingFraction: 0.8)) {
                                scriptStore.selectedScriptID = item.id
                                syncActiveScriptToHomeScreenWidgets(item)
                            }
                        } label: {
                            VStack(alignment: .leading, spacing: 7) {
                                HStack {
                                    if item.isPinned {
                                        Image(systemName: "pin")
                                            .font(.caption2)
                                            .foregroundColor(fg)
                                    }
                                    Text(item.title)
                                        .font(.headline.weight(.semibold))
                                        .foregroundColor(fg)
                                        .lineLimit(1)
                                    Spacer()
                                    Text(item.category.uppercased())
                                        .font(.system(size: 10, weight: .semibold))
                                        .padding(.horizontal, 8)
                                        .padding(.vertical, 3)
                                        .background(fg.opacity(0.10))
                                        .foregroundColor(fg)
                                        .clipShape(Capsule())
                                }

                                Text(item.content.replacingOccurrences(of: "\n", with: " "))
                                    .font(.subheadline)
                                    .foregroundColor(fg.opacity(0.65))
                                    .lineLimit(2)

                                HStack(spacing: 12) {
                                    Label("\(item.wordCount)w", systemImage: "text.word.spacing")
                                    Label(item.formattedDuration, systemImage: "clock")
                                    Label("\(item.targetWPM) WPM", systemImage: "speedometer")
                                }
                                .font(.caption2)
                                .foregroundColor(fg.opacity(0.65))
                            }
                            .padding(14)
                            .liquidGlass(cornerRadius: 20, isHighlighted: isSelected)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 14)
                .padding(.bottom, 16)
            }
        }
        .background(bg)
        .navigationTitle("Teleprompter")
        .searchable(text: $searchText, prompt: "Search scripts...")
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                HStack(spacing: 12) {
                    Button {
                        settings.toggleAppearanceMode()
                    } label: {
                        Image(systemName: isLight ? "moon" : "sun.max")
                            .font(.system(size: 16, weight: .light))
                            .foregroundColor(fg)
                    }
                    .accessibilityLabel("Toggle Theme")

                    Button {
                        isShowingSettingsSheet = true
                    } label: {
                        Image(systemName: "slider.horizontal.3")
                            .font(.system(size: 16, weight: .light))
                            .foregroundColor(fg)
                    }

                    Button {
                        cameraManager.showPostCaptureEditor = true
                    } label: {
                        HStack(spacing: 4) {
                            Image(systemName: "scissors")
                                .font(.system(size: 15, weight: .light))
                            if !cameraManager.recordedClips.isEmpty {
                                Text("\(cameraManager.recordedClips.count)")
                                    .font(.caption2.weight(.semibold))
                            }
                        }
                        .foregroundColor(fg)
                    }
                }
            }
            ToolbarItem(placement: .primaryAction) {
                Button {
                    withAnimation(.spring()) {
                        let created = scriptStore.createScript()
                        syncActiveScriptToHomeScreenWidgets(created)
                    }
                } label: {
                    Image(systemName: "plus")
                        .font(.system(size: 16, weight: .light))
                        .foregroundColor(fg)
                }
            }
        }
    }

    private var emptyDetailPlaceholder: some View {
        let fg = settings.primaryForeground
        return VStack(spacing: 16) {
            Image(systemName: "doc.text")
                .font(.system(size: 48, weight: .light))
                .foregroundColor(fg)
            Text("Select or Create a Script")
                .font(.title3.weight(.semibold))
                .foregroundColor(fg)
            Button("New Script") {
                _ = scriptStore.createScript()
            }
            .buttonStyle(.borderedProminent)
            .tint(fg)
        }
    }
}
