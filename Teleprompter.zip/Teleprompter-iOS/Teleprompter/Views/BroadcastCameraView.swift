import SwiftUI
import AVFoundation

struct BroadcastCameraView: View {
    let script: ScriptItem
    @EnvironmentObject var settings: TeleprompterSettings
    @EnvironmentObject var cameraManager: CameraRecordingManager
    @Environment(\.dismiss) private var dismiss

    @State private var selectedZoom: CGFloat = 1.0
    @State private var showGrid: Bool = true
    @State private var overlayOpacity: Double = 0.78
    @State private var isScrollingScript: Bool = false
    @State private var scriptScrollOffset: CGFloat = 0.0
    @State private var recordingSeconds: Int = 0
    @State private var showAreaTuner: Bool = false
    @GestureState private var liveDragOffset: CGSize = .zero

    private let zoomLevels: [CGFloat] = [1.0, 2.0, 3.0]
    private let frameTimer = Timer.publish(every: 1.0 / 60.0, on: .main, in: .common).autoconnect()
    private let secondTimer = Timer.publish(every: 1.0, on: .main, in: .common).autoconnect()

    private let paper = PrompterTheme.warmPaperColor
    private let ink = PrompterTheme.softInkColor

    var body: some View {
        GeometryReader { geo in
            ZStack {
                CameraPreviewRepresentable(session: cameraManager.session)
                    .ignoresSafeArea()

                LinearGradient(
                    colors: [ink.opacity(0.65), Color.clear, ink.opacity(0.75)],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()
                .allowsHitTesting(false)

                if showGrid {
                    Path { path in
                        let w = geo.size.width
                        let h = geo.size.height
                        path.move(to: CGPoint(x: w / 3, y: 0))
                        path.addLine(to: CGPoint(x: w / 3, y: h))
                        path.move(to: CGPoint(x: (w / 3) * 2, y: 0))
                        path.addLine(to: CGPoint(x: (w / 3) * 2, y: h))
                        path.move(to: CGPoint(x: 0, y: h / 3))
                        path.addLine(to: CGPoint(x: w, y: h / 3))
                        path.move(to: CGPoint(x: 0, y: (h / 3) * 2))
                        path.addLine(to: CGPoint(x: w, y: (h / 3) * 2))
                    }
                    .stroke(paper.opacity(0.22), lineWidth: 1)
                    .ignoresSafeArea()
                    .allowsHitTesting(false)
                }

                VStack(spacing: 12) {
                    // Top Camera Studio Bar
                    HStack(spacing: 10) {
                        Button {
                            dismiss()
                        } label: {
                            Image(systemName: "xmark")
                                .font(.system(size: 15, weight: .light))
                                .foregroundColor(paper)
                                .frame(width: 34, height: 34)
                                .background(ink.opacity(0.78))
                                .clipShape(Circle())
                        }

                        HStack(spacing: 6) {
                            Circle()
                                .fill(paper)
                                .frame(width: 7, height: 7)
                            Text(cameraManager.isRecording
                                 ? String(format: "REC %02d:%02d", recordingSeconds / 60, recordingSeconds % 60)
                                 : (cameraManager.usingFrontCamera ? "Front • \(settings.videoFormat)" : "Back • \(settings.videoFormat)"))
                                .font(.caption.weight(.semibold).monospacedDigit())
                                .foregroundColor(paper)
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(ink.opacity(0.78))
                        .clipShape(Capsule())

                        Spacer()

                        HStack(spacing: 6) {
                            Button {
                                cameraManager.setCamera(front: true)
                            } label: {
                                Text("Front")
                                    .font(.caption.weight(.semibold))
                                    .padding(.horizontal, 10)
                                    .padding(.vertical, 6)
                                    .background(cameraManager.usingFrontCamera ? paper : ink.opacity(0.72))
                                    .foregroundColor(cameraManager.usingFrontCamera ? ink : paper)
                                    .clipShape(Capsule())
                            }

                            Button {
                                cameraManager.setCamera(front: false)
                            } label: {
                                Text("Back")
                                    .font(.caption.weight(.semibold))
                                    .padding(.horizontal, 10)
                                    .padding(.vertical, 6)
                                    .background(!cameraManager.usingFrontCamera ? paper : ink.opacity(0.72))
                                    .foregroundColor(!cameraManager.usingFrontCamera ? ink : paper)
                                    .clipShape(Capsule())
                            }
                        }

                        Button {
                            cameraManager.showPostCaptureEditor = true
                        } label: {
                            HStack(spacing: 4) {
                                Image(systemName: "scissors")
                                    .font(.system(size: 13, weight: .light))
                                Text("Clips (\(cameraManager.recordedClips.count))")
                                    .font(.caption.weight(.semibold))
                            }
                            .padding(.horizontal, 11)
                            .padding(.vertical, 6)
                            .background(ink.opacity(0.78))
                            .foregroundColor(paper)
                            .clipShape(Capsule())
                        }
                    }
                    .padding(.horizontal, 18)
                    .padding(.top, 8)

                    // Live Draggable & Resizable Script Overlay Box (Works Before & During Recording)
                    VStack(alignment: .leading, spacing: 8) {
                        // Drag Pill Handle
                        HStack {
                            Spacer()
                            Capsule()
                                .fill(paper.opacity(0.38))
                                .frame(width: 36, height: 4)
                            Spacer()
                        }
                        .padding(.top, 2)

                        HStack(spacing: 8) {
                            Button {
                                withAnimation(.spring()) {
                                    isScrollingScript.toggle()
                                }
                            } label: {
                                HStack(spacing: 5) {
                                    Image(systemName: isScrollingScript ? "pause.fill" : "play.fill")
                                    Text(isScrollingScript ? "Pause" : "Scroll")
                                }
                                .font(.caption.weight(.semibold))
                                .padding(.horizontal, 10)
                                .padding(.vertical, 5)
                                .background(paper)
                                .foregroundColor(ink)
                                .clipShape(Capsule())
                            }

                            Button {
                                withAnimation(.spring()) {
                                    scriptScrollOffset = 0
                                }
                            } label: {
                                Image(systemName: "arrow.counterclockwise")
                                    .font(.system(size: 12, weight: .light))
                                    .foregroundColor(paper)
                                    .padding(6)
                                    .background(paper.opacity(0.14))
                                    .clipShape(Circle())
                            }

                            Spacer()

                            // Snap Position Presets (Top / Mid / Low) + Live Area Tuner Toggle
                            Button("Top") {
                                withAnimation(.spring()) { settings.overlayOffsetX = 0; settings.overlayOffsetY = 0 }
                            }
                            .font(.caption2.weight(.semibold))
                            .foregroundColor(paper.opacity(0.8))

                            Button("Mid") {
                                withAnimation(.spring()) { settings.overlayOffsetX = 0; settings.overlayOffsetY = 95 }
                            }
                            .font(.caption2.weight(.semibold))
                            .foregroundColor(paper.opacity(0.8))

                            Button("Low") {
                                withAnimation(.spring()) { settings.overlayOffsetX = 0; settings.overlayOffsetY = 180 }
                            }
                            .font(.caption2.weight(.semibold))
                            .foregroundColor(paper.opacity(0.8))

                            Button {
                                withAnimation(.spring(response: 0.26, dampingFraction: 0.8)) {
                                    showAreaTuner.toggle()
                                }
                            } label: {
                                HStack(spacing: 4) {
                                    Image(systemName: "arrow.up.left.and.arrow.down.right")
                                        .font(.system(size: 11, weight: .light))
                                    Text("Area")
                                }
                                .font(.caption2.weight(.semibold))
                                .padding(.horizontal, 9)
                                .padding(.vertical, 5)
                                .background(showAreaTuner ? paper : paper.opacity(0.14))
                                .foregroundColor(showAreaTuner ? ink : paper)
                                .clipShape(Capsule())
                            }
                        }

                        ScrollView(.vertical, showsIndicators: false) {
                            Text(script.content)
                                .font(.system(size: max(18, settings.fontSize * 0.62), weight: .semibold, design: settings.fontDesign.swiftUIFontDesign))
                                .foregroundColor(paper)
                                .lineSpacing(7)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .offset(y: -scriptScrollOffset)
                        }
                        .frame(height: settings.overlayHeight)
                        .clipped()

                        // Live Area Size, Opacity & Speed Adjuster (Usable While Recording)
                        if showAreaTuner {
                            VStack(spacing: 8) {
                                HStack(spacing: 12) {
                                    HStack(spacing: 6) {
                                        Text("Width")
                                            .font(.caption2)
                                            .foregroundColor(paper.opacity(0.75))
                                        Slider(value: $settings.overlayWidthRatio, in: 0.50...0.96)
                                            .tint(paper)
                                    }
                                    HStack(spacing: 6) {
                                        Text("Height")
                                            .font(.caption2)
                                            .foregroundColor(paper.opacity(0.75))
                                        Slider(value: $settings.overlayHeight, in: 90...320)
                                            .tint(paper)
                                    }
                                }
                                HStack(spacing: 12) {
                                    HStack(spacing: 6) {
                                        Text("Opacity")
                                            .font(.caption2)
                                            .foregroundColor(paper.opacity(0.75))
                                        Slider(value: $overlayOpacity, in: 0.25...0.95)
                                            .tint(paper)
                                    }
                                    HStack(spacing: 6) {
                                        Text("Speed")
                                            .font(.caption2)
                                            .foregroundColor(paper.opacity(0.75))
                                        Slider(value: $settings.wordsPerMinute, in: 60...260, step: 5)
                                            .tint(paper)
                                    }
                                }
                            }
                            .padding(.top, 4)
                            .transition(.opacity)
                        }
                    }
                    .padding(14)
                    .frame(width: geo.size.width * settings.overlayWidthRatio)
                    .background(ink.opacity(overlayOpacity))
                    .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 22, style: .continuous)
                            .stroke(paper.opacity(0.30), lineWidth: 1)
                    )
                    .offset(
                        x: settings.overlayOffsetX + liveDragOffset.width,
                        y: settings.overlayOffsetY + liveDragOffset.height
                    )
                    .gesture(
                        DragGesture()
                            .updating($liveDragOffset) { value, state, _ in
                                state = value.translation
                            }
                            .onEnded { value in
                                settings.overlayOffsetX = min(140, max(-140, settings.overlayOffsetX + value.translation.width))
                                settings.overlayOffsetY = min(260, max(-20, settings.overlayOffsetY + value.translation.height))
                            }
                    )

                    Spacer()

                    // Bottom Camera Controls Bar
                    VStack(spacing: 14) {
                        HStack(spacing: 12) {
                            ForEach(zoomLevels, id: \.self) { z in
                                Button {
                                    selectedZoom = z
                                    cameraManager.setZoom(z)
                                } label: {
                                    Text("\(Int(z))x")
                                        .font(.caption.weight(.semibold))
                                        .frame(width: 38, height: 38)
                                        .background(selectedZoom == z ? paper : ink.opacity(0.65))
                                        .foregroundColor(selectedZoom == z ? ink : paper)
                                        .clipShape(Circle())
                                }
                            }

                            Button {
                                cameraManager.flipCamera()
                            } label: {
                                Label(cameraManager.usingFrontCamera ? "Switch to Back" : "Switch to Front", systemImage: "arrow.triangle.2.circlepath.camera")
                                    .font(.caption.weight(.semibold))
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 9)
                                    .background(ink.opacity(0.65))
                                    .foregroundColor(paper)
                                    .clipShape(Capsule())
                            }
                        }

                        HStack(spacing: 32) {
                            Button {
                                showGrid.toggle()
                            } label: {
                                VStack(spacing: 4) {
                                    Image(systemName: "grid")
                                        .font(.system(size: 18, weight: .light))
                                    Text("Grid")
                                        .font(.caption2)
                                }
                                .foregroundColor(showGrid ? paper : paper.opacity(0.55))
                            }

                            Button {
                                if !cameraManager.isRecording {
                                    recordingSeconds = 0
                                    isScrollingScript = true
                                } else {
                                    isScrollingScript = false
                                }
                                cameraManager.toggleRecording()
                            } label: {
                                ZStack {
                                    Circle()
                                        .stroke(paper, lineWidth: 2.5)
                                        .frame(width: 70, height: 70)
                                    RoundedRectangle(cornerRadius: cameraManager.isRecording ? 8 : 30, style: .continuous)
                                        .fill(paper)
                                        .frame(width: cameraManager.isRecording ? 28 : 56, height: cameraManager.isRecording ? 28 : 56)
                                        .animation(.spring(response: 0.25, dampingFraction: 0.75), value: cameraManager.isRecording)
                                }
                            }

                            Button {
                                cameraManager.showPostCaptureEditor = true
                            } label: {
                                VStack(spacing: 4) {
                                    Image(systemName: "scissors")
                                        .font(.system(size: 18, weight: .light))
                                    Text("Edit Video")
                                        .font(.caption2)
                                }
                                .foregroundColor(paper)
                            }
                        }
                    }
                    .padding(16)
                    .background(ink.opacity(0.86))
                    .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 26, style: .continuous)
                            .stroke(paper.opacity(0.18), lineWidth: 1)
                    )
                    .padding(.horizontal, 18)
                    .padding(.bottom, 12)
                }
            }
        }
        .onAppear {
            cameraManager.configureIfNeeded()
        }
        .onReceive(frameTimer) { _ in
            guard isScrollingScript else { return }
            let pixelsPerSec = CGFloat(settings.wordsPerMinute) * 0.42
            scriptScrollOffset += pixelsPerSec / 60.0
        }
        .onReceive(secondTimer) { _ in
            if cameraManager.isRecording {
                recordingSeconds += 1
            }
        }
        .sheet(isPresented: $cameraManager.showPostCaptureEditor) {
            VideoClipEditorView()
                .environmentObject(cameraManager)
                .environmentObject(settings)
        }
    }
}
