import SwiftUI
import AVKit
import AVFoundation
import UIKit
import UniformTypeIdentifiers

struct ShareSheetView: UIViewControllerRepresentable {
    let activityItems: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

struct DocumentExportPicker: UIViewControllerRepresentable {
    let fileURL: URL
    var onCompletion: (Bool) -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forExporting: [fileURL], asCopy: true)
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(onCompletion: onCompletion)
    }

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onCompletion: (Bool) -> Void
        init(onCompletion: @escaping (Bool) -> Void) {
            self.onCompletion = onCompletion
        }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            onCompletion(true)
        }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            onCompletion(false)
        }
    }
}

struct VideoClipEditorView: View {
    @EnvironmentObject var cameraManager: CameraRecordingManager
    @EnvironmentObject var settings: TeleprompterSettings
    @Environment(\.dismiss) private var dismiss

    @State private var player: AVPlayer?
    @State private var startTime: Double = 0.0
    @State private var endTime: Double = 10.0
    @State private var totalDuration: Double = 10.0
    @State private var playbackRate: Float = 1.0
    @State private var isMuted: Bool = false
    @State private var isTrimming: Bool = false
    @State private var toastMessage: String?
    @State private var isShowingShareSheet: Bool = false
    @State private var isShowingFilesExporter: Bool = false

    private let rates: [Float] = [0.5, 1.0, 1.25, 1.5, 2.0]

    var currentClip: RecordedClip? {
        cameraManager.activeClipForEditor ?? cameraManager.recordedClips.first
    }

    var body: some View {
        let isLight = settings.isLightMode
        let fg = settings.primaryForeground
        let bg = settings.primaryBackground

        NavigationStack {
            ZStack {
                bg.ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 18) {
                        if let clip = currentClip {
                            VStack(spacing: 12) {
                                ZStack(alignment: .topLeading) {
                                    if let player = player {
                                        VideoPlayer(player: player)
                                            .frame(height: 300)
                                            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                                    } else {
                                        RoundedRectangle(cornerRadius: 20, style: .continuous)
                                            .fill(fg.opacity(0.08))
                                            .frame(height: 300)
                                            .overlay(ProgressView().tint(fg))
                                    }

                                    HStack(spacing: 8) {
                                        Image(systemName: "film")
                                            .font(.system(size: 13, weight: .light))
                                        Text(clip.title)
                                            .font(.caption.weight(.semibold))
                                        Text("• \(String(format: "%.1fs", totalDuration))")
                                            .font(.caption.monospacedDigit())
                                    }
                                    .foregroundColor(fg)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 6)
                                    .background(bg.opacity(0.84))
                                    .clipShape(Capsule())
                                    .padding(12)
                                }

                                HStack(spacing: 10) {
                                    Button {
                                        isMuted.toggle()
                                        player?.isMuted = isMuted
                                    } label: {
                                        Label(isMuted ? "Muted" : "Sound On", systemImage: isMuted ? "speaker.slash" : "speaker.wave.2")
                                            .font(.caption.weight(.semibold))
                                            .padding(.horizontal, 12)
                                            .padding(.vertical, 8)
                                            .background(isMuted ? fg : fg.opacity(0.08))
                                            .foregroundColor(isMuted ? bg : fg)
                                            .clipShape(Capsule())
                                    }

                                    Spacer()

                                    Text("Speed")
                                        .font(.caption2.weight(.semibold))
                                        .foregroundColor(fg.opacity(0.65))

                                    ForEach(rates, id: \.self) { rate in
                                        Button {
                                            playbackRate = rate
                                            player?.playImmediately(atRate: rate)
                                        } label: {
                                            Text("\(String(format: "%g", rate))x")
                                                .font(.caption2.weight(.semibold))
                                                .padding(.horizontal, 9)
                                                .padding(.vertical, 6)
                                                .background(playbackRate == rate ? fg : fg.opacity(0.08))
                                                .foregroundColor(playbackRate == rate ? bg : fg)
                                                .clipShape(Capsule())
                                        }
                                    }
                                }
                            }
                            .padding(16)
                            .liquidGlass(cornerRadius: 24, isHighlighted: true)

                            // Trim Video Card
                            VStack(alignment: .leading, spacing: 14) {
                                HStack {
                                    Label("Trim Video Clip", systemImage: "scissors")
                                        .font(.headline.weight(.semibold))
                                        .foregroundColor(fg)
                                    Spacer()
                                    Text("Selected: \(String(format: "%.1fs", max(0.1, endTime - startTime)))")
                                        .font(.caption.weight(.semibold).monospacedDigit())
                                        .padding(.horizontal, 10)
                                        .padding(.vertical, 5)
                                        .background(fg.opacity(0.10))
                                        .foregroundColor(fg)
                                        .clipShape(Capsule())
                                }

                                GeometryReader { geo in
                                    let w = max(1, geo.size.width)
                                    let startFrac = CGFloat(startTime / max(0.1, totalDuration))
                                    let endFrac = CGFloat(endTime / max(0.1, totalDuration))
                                    ZStack(alignment: .leading) {
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(fg.opacity(0.08))
                                            .frame(height: 28)

                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(fg)
                                            .frame(width: max(12, (endFrac - startFrac) * w), height: 28)
                                            .offset(x: startFrac * w)
                                    }
                                }
                                .frame(height: 28)

                                VStack(spacing: 10) {
                                    HStack {
                                        Text("Start: \(String(format: "%.1fs", startTime))")
                                            .font(.caption.weight(.semibold).monospacedDigit())
                                            .frame(width: 86, alignment: .leading)
                                        Slider(
                                            value: Binding(
                                                get: { startTime },
                                                set: { newVal in
                                                    startTime = min(newVal, max(0, endTime - 0.3))
                                                    seekPlayer(to: startTime)
                                                }
                                            ),
                                            in: 0...max(0.5, totalDuration)
                                        )
                                        .tint(fg)
                                    }

                                    HStack {
                                        Text("End: \(String(format: "%.1fs", endTime))")
                                            .font(.caption.weight(.semibold).monospacedDigit())
                                            .frame(width: 86, alignment: .leading)
                                        Slider(
                                            value: Binding(
                                                get: { endTime },
                                                set: { newVal in
                                                    endTime = max(newVal, min(totalDuration, startTime + 0.3))
                                                    seekPlayer(to: endTime)
                                                }
                                            ),
                                            in: 0...max(0.5, totalDuration)
                                        )
                                        .tint(fg)
                                    }
                                }
                                .foregroundColor(fg)

                                HStack(spacing: 12) {
                                    Button {
                                        seekPlayer(to: startTime)
                                        player?.playImmediately(atRate: playbackRate)
                                    } label: {
                                        Label("Preview Trim", systemImage: "play")
                                            .font(.subheadline.weight(.semibold))
                                            .frame(maxWidth: .infinity)
                                            .padding(.vertical, 12)
                                            .background(fg.opacity(0.08))
                                            .foregroundColor(fg)
                                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                                    }

                                    Button {
                                        guard !isTrimming else { return }
                                        isTrimming = true
                                        cameraManager.trimVideo(sourceURL: clip.url, startTime: startTime, endTime: endTime) { result in
                                            isTrimming = false
                                            switch result {
                                            case .success(let newClip):
                                                loadClip(newClip)
                                                showToast("Trimmed to \(String(format: "%.1fs", newClip.durationSeconds))")
                                            case .failure(let err):
                                                showToast("Trim error: \(err.localizedDescription)")
                                            }
                                        }
                                    } label: {
                                        HStack(spacing: 8) {
                                            if isTrimming {
                                                ProgressView().tint(bg)
                                            } else {
                                                Image(systemName: "scissors")
                                            }
                                            Text(isTrimming ? "Trimming..." : "Apply Trim")
                                                .fontWeight(.semibold)
                                        }
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 12)
                                        .background(fg)
                                        .foregroundColor(bg)
                                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                                    }
                                }
                            }
                            .padding(18)
                            .liquidGlass(cornerRadius: 24)

                            // Save & Export Actions
                            VStack(alignment: .leading, spacing: 12) {
                                Label("Save & Share Video", systemImage: "square.and.arrow.down")
                                    .font(.headline.weight(.semibold))
                                    .foregroundColor(fg)

                                HStack(spacing: 12) {
                                    Button {
                                        cameraManager.saveVideoToPhotos(url: clip.url) { _, msg in
                                            showToast(msg)
                                        }
                                    } label: {
                                        VStack(spacing: 6) {
                                            Image(systemName: "photo.on.rectangle")
                                                .font(.system(size: 20, weight: .light))
                                            Text("Save to Photos")
                                                .font(.caption.weight(.semibold))
                                        }
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 14)
                                        .background(fg)
                                        .foregroundColor(bg)
                                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                                    }

                                    Button {
                                        isShowingFilesExporter = true
                                    } label: {
                                        VStack(spacing: 6) {
                                            Image(systemName: "folder")
                                                .font(.system(size: 20, weight: .light))
                                            Text("Save to Files")
                                                .font(.caption.weight(.semibold))
                                        }
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 14)
                                        .background(fg.opacity(0.08))
                                        .foregroundColor(fg)
                                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                                    }

                                    Button {
                                        isShowingShareSheet = true
                                    } label: {
                                        VStack(spacing: 6) {
                                            Image(systemName: "square.and.arrow.up")
                                                .font(.system(size: 20, weight: .light))
                                            Text("Share Video")
                                                .font(.caption.weight(.semibold))
                                        }
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 14)
                                        .background(fg.opacity(0.08))
                                        .foregroundColor(fg)
                                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                                    }
                                }
                            }
                            .padding(18)
                            .liquidGlass(cornerRadius: 24)

                            if cameraManager.recordedClips.count > 1 {
                                VStack(alignment: .leading, spacing: 10) {
                                    Text("All Recorded Takes")
                                        .font(.subheadline.weight(.semibold))
                                        .foregroundColor(fg.opacity(0.65))

                                    ForEach(cameraManager.recordedClips) { item in
                                        let isCurrent = (item.id == clip.id)
                                        Button {
                                            cameraManager.activeClipForEditor = item
                                            loadClip(item)
                                        } label: {
                                            HStack {
                                                Image(systemName: isCurrent ? "play.circle.fill" : "film")
                                                    .foregroundColor(fg)
                                                Text(item.title)
                                                    .font(.subheadline.weight(.medium))
                                                    .foregroundColor(fg)
                                                Spacer()
                                                Text(String(format: "%.1fs", item.durationSeconds))
                                                    .font(.caption.monospacedDigit())
                                                    .foregroundColor(fg.opacity(0.65))
                                            }
                                            .padding(12)
                                            .background(isCurrent ? fg.opacity(0.12) : fg.opacity(0.04))
                                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                                        }
                                    }
                                }
                                .padding(18)
                                .liquidGlass(cornerRadius: 24)
                            }
                        } else {
                            VStack(spacing: 14) {
                                Image(systemName: "video")
                                    .font(.system(size: 46, weight: .light))
                                    .foregroundColor(fg)
                                Text("No Recorded Video Yet")
                                    .font(.title3.weight(.semibold))
                                    .foregroundColor(fg)
                                Text("Record a take in the Camera or Reading Screen to trim, preview, and save it to Photos or Files.")
                                    .font(.subheadline)
                                    .multilineTextAlignment(.center)
                                    .foregroundColor(fg.opacity(0.65))
                            }
                            .padding(32)
                            .liquidGlass(cornerRadius: 24)
                        }
                    }
                    .padding(16)
                }

                if let toast = toastMessage {
                    VStack {
                        Spacer()
                        HStack(spacing: 10) {
                            Image(systemName: "checkmark")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(bg)
                            Text(toast)
                                .font(.subheadline.weight(.semibold))
                                .foregroundColor(bg)
                        }
                        .padding(.horizontal, 18)
                        .padding(.vertical, 12)
                        .background(fg)
                        .clipShape(Capsule())
                        .padding(.bottom, 24)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                }
            }
            .navigationTitle("Video Editor & Trim")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") {
                        player?.pause()
                        dismiss()
                    }
                    .fontWeight(.semibold)
                    .foregroundColor(fg)
                }
            }
            .onAppear {
                if let clip = currentClip {
                    loadClip(clip)
                }
            }
            .onDisappear {
                player?.pause()
            }
            .sheet(isPresented: $isShowingShareSheet) {
                if let clip = currentClip {
                    ShareSheetView(activityItems: [clip.url])
                }
            }
            .sheet(isPresented: $isShowingFilesExporter) {
                if let clip = currentClip {
                    DocumentExportPicker(fileURL: clip.url) { saved in
                        if saved {
                            showToast("Saved video to Files")
                        }
                    }
                }
            }
        }
        .preferredColorScheme(isLight ? .light : .dark)
    }

    private func loadClip(_ clip: RecordedClip) {
        player?.pause()
        let asset = AVURLAsset(url: clip.url)
        let dur = max(0.5, CMTimeGetSeconds(asset.duration))
        totalDuration = dur.isFinite ? dur : clip.durationSeconds
        startTime = 0.0
        endTime = totalDuration
        let newPlayer = AVPlayer(url: clip.url)
        newPlayer.isMuted = isMuted
        player = newPlayer
        newPlayer.play()
    }

    private func seekPlayer(to seconds: Double) {
        let cm = CMTime(seconds: max(0, seconds), preferredTimescale: 600)
        player?.seek(to: cm, toleranceBefore: .zero, toleranceAfter: .zero)
    }

    private func showToast(_ text: String) {
        withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
            toastMessage = text
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.6) {
            withAnimation {
                if toastMessage == text {
                    toastMessage = nil
                }
            }
        }
    }
}
