import SwiftUI

struct ScriptEditorView: View {
    @Binding var script: ScriptItem
    @EnvironmentObject var settings: TeleprompterSettings
    @EnvironmentObject var cameraManager: CameraRecordingManager
    @StateObject private var voiceEngine = VoiceTrackEngine()

    var onStartPrompter: () -> Void
    var onOpenCameraStudio: () -> Void
    var onOpenSettings: () -> Void

    private let categories = ["Keynote", "Video", "Update", "Podcast"]

    var body: some View {
        let fg = settings.primaryForeground
        let bg = settings.primaryBackground

        VStack(spacing: 14) {
            VStack(spacing: 12) {
                HStack(spacing: 12) {
                    TextField("Script Title", text: $script.title)
                        .font(.title2.weight(.bold))
                        .foregroundColor(fg)
                        .textFieldStyle(.plain)

                    Picker("Category", selection: $script.category) {
                        ForEach(categories, id: \.self) { cat in
                            Text(cat).tag(cat)
                        }
                    }
                    .pickerStyle(.menu)
                    .tint(fg)

                    Button {
                        withAnimation(.spring()) {
                            script.isPinned.toggle()
                        }
                    } label: {
                        Image(systemName: script.isPinned ? "pin.fill" : "pin")
                            .font(.system(size: 14, weight: .light))
                            .foregroundColor(script.isPinned ? fg : fg.opacity(0.6))
                    }
                    .buttonStyle(.bordered)
                }

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        metricPill(icon: "text.alignleft", label: "\(script.wordCount) words")
                        metricPill(icon: "timer", label: "Time \(script.formattedDuration)")

                        HStack(spacing: 6) {
                            Image(systemName: "speedometer")
                                .font(.system(size: 12, weight: .light))
                                .foregroundColor(fg)
                            Text("\(script.targetWPM) WPM")
                                .font(.caption.weight(.semibold))
                                .foregroundColor(fg)
                            Stepper("", value: $script.targetWPM, in: 60...260, step: 5)
                                .labelsHidden()
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 4)
                        .background(fg.opacity(0.06))
                        .clipShape(Capsule())

                        Button {
                            voiceEngine.toggleListenAloud(text: script.content)
                        } label: {
                            Label(voiceEngine.isSpeakingAloud ? "Stop Voice" : "Listen", systemImage: voiceEngine.isSpeakingAloud ? "stop.circle" : "speaker.wave.2")
                                .font(.caption.weight(.semibold))
                                .padding(.horizontal, 12)
                                .padding(.vertical, 8)
                                .background(voiceEngine.isSpeakingAloud ? fg : fg.opacity(0.08))
                                .foregroundColor(voiceEngine.isSpeakingAloud ? bg : fg)
                                .clipShape(Capsule())
                        }
                        .buttonStyle(.plain)

                        Button {
                            withAnimation(.spring()) {
                                script.formatShortLines()
                            }
                        } label: {
                            Label("Short Lines", systemImage: "text.line.first.and.arrowtriangle.forward")
                                .font(.caption.weight(.semibold))
                                .padding(.horizontal, 12)
                                .padding(.vertical, 8)
                                .background(fg.opacity(0.08))
                                .foregroundColor(fg)
                                .clipShape(Capsule())
                        }
                        .buttonStyle(.plain)

                        Button {
                            onOpenCameraStudio()
                        } label: {
                            Label("Camera", systemImage: "camera")
                                .font(.caption.weight(.semibold))
                                .padding(.horizontal, 12)
                                .padding(.vertical, 8)
                                .background(fg.opacity(0.08))
                                .foregroundColor(fg)
                                .clipShape(Capsule())
                        }
                        .buttonStyle(.plain)

                        Button {
                            onOpenSettings()
                        } label: {
                            Label("Settings", systemImage: "slider.horizontal.3")
                                .font(.caption.weight(.semibold))
                                .padding(.horizontal, 12)
                                .padding(.vertical, 8)
                                .background(fg.opacity(0.08))
                                .foregroundColor(fg)
                                .clipShape(Capsule())
                        }
                        .buttonStyle(.plain)

                        Button {
                            onStartPrompter()
                        } label: {
                            HStack(spacing: 6) {
                                Image(systemName: "play.fill")
                                Text("Start Reading")
                                    .fontWeight(.semibold)
                            }
                            .font(.subheadline)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 9)
                            .background(fg)
                            .foregroundColor(bg)
                            .clipShape(Capsule())
                        }
                        .buttonStyle(.plain)
                    }
                }

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        Text("ADD NOTE")
                            .font(.system(size: 10, weight: .semibold))
                            .foregroundColor(fg.opacity(0.6))

                        cueInsertButton("[PAUSE]", icon: "pause.circle")
                        cueInsertButton("[EMPHASIS]", icon: "bold")
                        cueInsertButton("[SLOW]", icon: "tortoise")
                        cueInsertButton("[FAST]", icon: "hare")
                        cueInsertButton("[LOOK AT LENS]", icon: "eye")
                    }
                }
            }
            .padding(16)
            .liquidGlass(cornerRadius: 24)

            TextEditor(text: $script.content)
                .font(.system(size: 20, weight: .regular, design: settings.fontDesign.swiftUIFontDesign))
                .foregroundColor(fg)
                .lineSpacing(9)
                .padding(18)
                .scrollContentBackground(.hidden)
                .liquidGlass(cornerRadius: 24)
        }
        .padding(14)
        .background(bg)
        .navigationBarTitleDisplayMode(.inline)
        .onDisappear {
            voiceEngine.stop()
        }
    }

    private func metricPill(icon: String, label: String) -> some View {
        let fg = settings.primaryForeground
        return HStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 12, weight: .light))
                .foregroundColor(fg)
            Text(label)
                .font(.caption.weight(.semibold))
                .foregroundColor(fg)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(fg.opacity(0.06))
        .clipShape(Capsule())
    }

    private func cueInsertButton(_ tag: String, icon: String) -> some View {
        let fg = settings.primaryForeground
        return Button {
            script.content += "\n\(tag)\n"
            script.lastModified = Date()
        } label: {
            Label(tag, systemImage: icon)
                .font(.caption.weight(.semibold))
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(fg.opacity(0.08))
                .foregroundColor(fg)
                .overlay(
                    Capsule()
                        .stroke(fg.opacity(0.24), lineWidth: 1)
                )
                .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }
}
