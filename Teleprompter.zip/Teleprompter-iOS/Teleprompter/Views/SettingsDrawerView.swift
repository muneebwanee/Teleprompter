import SwiftUI

struct SettingsDrawerView: View {
    @EnvironmentObject var settings: TeleprompterSettings
    @Environment(\.dismiss) private var dismiss

    @State private var featureTitle: String = ""
    @State private var featureArea: String = "Voice Glide"
    @State private var featureSentMessage: Bool = false

    private let gridColumns = [
        GridItem(.flexible(), spacing: 10),
        GridItem(.flexible(), spacing: 10)
    ]

    var body: some View {
        let isLight = settings.isLightMode
        let fg = settings.primaryForeground
        let bg = settings.primaryBackground

        NavigationStack {
            ZStack {
                bg.ignoresSafeArea()

                ScrollView(.vertical, showsIndicators: false) {
                    VStack(spacing: 16) {
                        // 1. Appearance
                        VStack(alignment: .leading, spacing: 14) {
                            HStack {
                                sectionTitle("Appearance", icon: isLight ? "moon" : "sun.max")
                                Spacer()
                                Button {
                                    settings.toggleAppearanceMode()
                                } label: {
                                    Image(systemName: isLight ? "moon" : "sun.max")
                                        .font(.system(size: 16, weight: .light))
                                        .foregroundColor(fg)
                                        .frame(width: 34, height: 34)
                                        .background(fg.opacity(0.08))
                                        .clipShape(Circle())
                                }
                                .buttonStyle(.plain)
                            }

                            HStack(spacing: 10) {
                                paletteCard(
                                    title: "Warm Paper",
                                    subtitle: "Daylight Surface",
                                    icon: "sun.max",
                                    cardBg: PrompterTheme.warmPaperColor,
                                    cardFg: PrompterTheme.softInkColor,
                                    selected: isLight
                                ) {
                                    settings.theme = .warmPaper
                                }

                                paletteCard(
                                    title: "Soft Ink",
                                    subtitle: "Low-Glare Dark",
                                    icon: "moon",
                                    cardBg: PrompterTheme.softInkColor,
                                    cardFg: PrompterTheme.warmPaperColor,
                                    selected: !isLight
                                ) {
                                    settings.theme = .softInk
                                }
                            }
                        }
                        .padding(18)
                        .liquidGlass(cornerRadius: 24)

                        // 2. Text Settings
                        VStack(alignment: .leading, spacing: 14) {
                            sectionTitle("Text Settings", icon: "textformat")

                            LazyVGrid(columns: gridColumns, spacing: 10) {
                                ForEach(PrompterFontDesign.allCases) { font in
                                    let isSelected = (settings.fontDesign == font)
                                    Button {
                                        settings.fontDesign = font
                                    } label: {
                                        VStack(alignment: .leading, spacing: 4) {
                                            HStack {
                                                Text("Aa")
                                                    .font(.system(size: 20, weight: .semibold, design: font.swiftUIFontDesign))
                                                    .foregroundColor(isSelected ? bg : fg)
                                                Spacer()
                                                if isSelected {
                                                    Image(systemName: "checkmark")
                                                        .font(.system(size: 12, weight: .light))
                                                        .foregroundColor(bg)
                                                }
                                            }
                                            Text(font.rawValue)
                                                .font(.caption.weight(.medium))
                                                .foregroundColor(isSelected ? bg : fg)
                                        }
                                        .padding(12)
                                        .background(
                                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                                .fill(isSelected ? fg : fg.opacity(0.05))
                                        )
                                    }
                                    .buttonStyle(.plain)
                                }
                            }

                            sliderRow(title: "Text Size", valueText: "\(Int(settings.fontSize)) pt", value: $settings.fontSize, range: 24...76, step: 2)
                            sliderRow(title: "Line Spacing", valueText: "\(Int(settings.lineSpacing)) pt", value: $settings.lineSpacing, range: 6...32, step: 2)
                            sliderRow(title: "Side Margins", valueText: "\(Int(settings.horizontalMargin)) pt", value: $settings.horizontalMargin, range: 16...120, step: 4)

                            Toggle("Easy Read (Bold Word Starts)", isOn: $settings.easyReadEnabled)
                                .tint(fg)
                            Toggle("Dim Unread Lines", isOn: $settings.focusDimmingEnabled)
                                .tint(fg)
                        }
                        .foregroundColor(fg)
                        .padding(18)
                        .liquidGlass(cornerRadius: 24)

                        // 3. Voice Glide Settings
                        VStack(alignment: .leading, spacing: 14) {
                            sectionTitle("Voice Glide", icon: "waveform")

                            Toggle("Enable Voice Glide", isOn: $settings.voiceGlideEnabled)
                                .tint(fg)
                            sliderRow(title: "Glide Smoothing", valueText: "\(Int(settings.voiceGlideSmoothing))%", value: $settings.voiceGlideSmoothing, range: 20...100, step: 5)
                            sliderRow(title: "Mic Sensitivity", valueText: "\(Int(settings.micSensitivity))%", value: $settings.micSensitivity, range: 20...100, step: 5)
                            sliderRow(title: "Background Noise Filter", valueText: "\(Int(settings.noiseGateThreshold))%", value: $settings.noiseGateThreshold, range: 5...60, step: 5)
                            sliderRow(title: "Pause Hold Time", valueText: String(format: "%.1fs", settings.voiceSilenceHold), value: $settings.voiceSilenceHold, range: 0.5...4.0, step: 0.5)
                            Toggle("Auto-Resume When Speaking", isOn: $settings.voiceAutoResume)
                                .tint(fg)
                        }
                        .foregroundColor(fg)
                        .padding(18)
                        .liquidGlass(cornerRadius: 24)

                        // 4. Precision Settings
                        VStack(alignment: .leading, spacing: 14) {
                            sectionTitle("Precision Settings", icon: "scope")

                            sliderRow(title: "Reading Speed", valueText: "\(Int(settings.wordsPerMinute)) WPM", value: $settings.wordsPerMinute, range: 60...260, step: 1)
                            sliderRow(title: "Smooth Start & Stop", valueText: String(format: "%.1fs", settings.smoothRampSeconds), value: $settings.smoothRampSeconds, range: 0.0...2.5, step: 0.1)
                            sliderRow(title: "Eye-Line Position", valueText: "\(Int(settings.eyeLineVerticalRatio * 100))%", value: $settings.eyeLineVerticalRatio, range: 0.15...0.75, step: 0.01)
                            sliderRow(title: "Reading Band Size", valueText: "\(Int(settings.eyeLineBandHeight)) pt", value: $settings.eyeLineBandHeight, range: 48...140, step: 4)
                            Stepper("Start Countdown: \(settings.countdownSeconds) sec", value: $settings.countdownSeconds, in: 0...10)

                            Toggle("Lock Speed to Target Time", isOn: $settings.lockSpeedToTargetTime)
                                .tint(fg)
                            Toggle("Auto-Pause at [PAUSE] Notes", isOn: $settings.autoWaitOnPauseTag)
                                .tint(fg)
                            Toggle("Loop Script When Finished", isOn: $settings.loopScriptEnabled)
                                .tint(fg)
                        }
                        .foregroundColor(fg)
                        .padding(18)
                        .liquidGlass(cornerRadius: 24)

                        // 5. External Display Settings
                        VStack(alignment: .leading, spacing: 14) {
                            sectionTitle("External Display", icon: "display")

                            Picker("Output Mode", selection: $settings.externalDisplayMode) {
                                Text("Clean Script Only").tag("Clean Script Only")
                                Text("Full App Mirror").tag("Full App Mirror")
                                Text("Script + Timer").tag("Script + Timer")
                            }
                            .pickerStyle(.menu)
                            .tint(fg)

                            Toggle("Flip External Screen Left-Right", isOn: $settings.externalMirrorHorizontal)
                                .tint(fg)
                            Toggle("Flip External Screen Up-Down", isOn: $settings.externalMirrorVertical)
                                .tint(fg)
                            sliderRow(title: "Screen Border Margin", valueText: "\(Int(settings.externalOverscanMargin))%", value: $settings.externalOverscanMargin, range: 0...15, step: 1)
                        }
                        .foregroundColor(fg)
                        .padding(18)
                        .liquidGlass(cornerRadius: 24)

                        // 6. Livestream Connection & Settings
                        VStack(alignment: .leading, spacing: 14) {
                            sectionTitle("Livestream Connection", icon: "dot.radiowaves.left.and.right")

                            Picker("Stream Type", selection: $settings.livestreamStream Type) {
                                Text("YouTube / Twitch Live").tag("YouTube / Twitch Live")
                                Text("Fast Live Stream").tag("Fast Live Stream")
                                Text("Computer / OBS Wi-Fi").tag("Computer / OBS Wi-Fi")
                            }
                            .pickerStyle(.menu)
                            .tint(fg)

                            TextField("Server URL (rtmp://...)", text: $settings.livestreamServerURL)
                                .font(.caption)
                                .padding(10)
                                .background(fg.opacity(0.06))
                                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))

                            SecureField("Stream Key", text: $settings.livestreamKey)
                                .font(.caption)
                                .padding(10)
                                .background(fg.opacity(0.06))
                                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))

                            sliderRow(title: "Stream Quality", valueText: String(format: "%.1f Mbps", settings.livestreamBitrateMbps), value: $settings.livestreamBitrateMbps, range: 2.0...15.0, step: 0.5)
                            Toggle("Save Local Video Copy While Streaming", isOn: $settings.livestreamSaveLocalCopy)
                                .tint(fg)
                        }
                        .foregroundColor(fg)
                        .padding(18)
                        .liquidGlass(cornerRadius: 24)

                        // 7. Remote Control & Settings
                        VStack(alignment: .leading, spacing: 14) {
                            sectionTitle("Remote Control", icon: "keyboard")

                            Toggle("Bluetooth Remotes & Keyboards", isOn: $settings.bluetoothRemoteEnabled)
                                .tint(fg)
                            Toggle("Second Device Wi-Fi Remote", isOn: $settings.secondDeviceRemoteEnabled)
                                .tint(fg)
                            Picker("Foot Pedal Mode", selection: $settings.footPedalMode) {
                                Text("Tap to Start / Stop").tag("Tap to Start / Stop")
                                Text("Hold Down to Scroll").tag("Hold Down to Scroll")
                            }
                            .pickerStyle(.menu)
                            .tint(fg)
                        }
                        .foregroundColor(fg)
                        .padding(18)
                        .liquidGlass(cornerRadius: 24)

                        // 8. Feature Request, Privacy Policy, Terms of Service & About
                        VStack(alignment: .leading, spacing: 10) {
                            sectionTitle("More & Legal", icon: "shield")

                            NavigationLink {
                                FeatureRequestView()
                                    .environmentObject(settings)
                            } label: {
                                navRow(title: "Feature Request", subtitle: "Share ideas for new features", icon: "bubble.left")
                            }
                            .buttonStyle(.plain)

                            NavigationLink {
                                PrivacyPolicyView()
                                    .environmentObject(settings)
                            } label: {
                                navRow(title: "Privacy Policy", subtitle: "On-Device Storage • Zero Tracking", icon: "lock")
                            }
                            .buttonStyle(.plain)

                            NavigationLink {
                                TermsOfServiceView()
                                    .environmentObject(settings)
                            } label: {
                                navRow(title: "Terms of Service", subtitle: "Your Scripts & Recordings", icon: "doc.plaintext")
                            }
                            .buttonStyle(.plain)

                            NavigationLink {
                                AboutDeveloperView()
                                    .environmentObject(settings)
                            } label: {
                                navRow(title: "v0.0.1 Teleprompter", subtitle: "Developed by muneebwanee (github.com/muneebwanee)", icon: "info.circle")
                            }
                            .buttonStyle(.plain)

                            Button {
                                settings.resetToDefaults()
                            } label: {
                                HStack(spacing: 8) {
                                    Image(systemName: "arrow.counterclockwise")
                                        .font(.system(size: 14, weight: .light))
                                    Text("Reset Settings")
                                        .fontWeight(.semibold)
                                }
                                .font(.subheadline)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                                .background(fg.opacity(0.08))
                                .foregroundColor(fg)
                                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                            }
                            .buttonStyle(.plain)
                        }
                        .padding(18)
                        .liquidGlass(cornerRadius: 24)
                    }
                    .padding(16)
                }
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button {
                        settings.toggleAppearanceMode()
                    } label: {
                        Image(systemName: isLight ? "moon" : "sun.max")
                            .font(.system(size: 15, weight: .light))
                            .foregroundColor(fg)
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                        .fontWeight(.semibold)
                        .foregroundColor(fg)
                }
            }
        }
        .preferredColorScheme(isLight ? .light : .dark)
    }

    private func sectionTitle(_ title: String, icon: String) -> some View {
        let fg = settings.primaryForeground
        return HStack(spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 15, weight: .light))
                .foregroundColor(fg)
            Text(title)
                .font(.headline.weight(.semibold))
                .foregroundColor(fg)
        }
    }

    private func paletteCard(title: String, subtitle: String, icon: String, cardBg: Color, cardFg: Color, selected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Image(systemName: icon)
                        .font(.system(size: 15, weight: .light))
                        .foregroundColor(cardFg)
                    Spacer()
                    if selected {
                        Image(systemName: "checkmark")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(cardFg)
                    }
                }
                Text(title)
                    .font(.subheadline.weight(.semibold))
                    .foregroundColor(cardFg)
                Text(subtitle)
                    .font(.caption2)
                    .foregroundColor(cardFg.opacity(0.68))
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(cardBg)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .stroke(cardFg.opacity(selected ? 0.55 : 0.16), lineWidth: selected ? 1.5 : 1.0)
            )
        }
        .buttonStyle(.plain)
    }

    private func sliderRow(title: String, valueText: String, value: Binding<Double>, range: ClosedRange<Double>, step: Double) -> some View {
        let fg = settings.primaryForeground
        return VStack(spacing: 4) {
            HStack {
                Text(title)
                    .font(.subheadline)
                    .foregroundColor(fg)
                Spacer()
                Text(valueText)
                    .font(.caption.weight(.semibold).monospacedDigit())
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(fg.opacity(0.10))
                    .foregroundColor(fg)
                    .clipShape(Capsule())
            }
            Slider(value: value, in: range, step: step)
                .tint(fg)
        }
    }

    private func navRow(title: String, subtitle: String, icon: String) -> some View {
        let fg = settings.primaryForeground
        return HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 15, weight: .light))
                .foregroundColor(fg)
                .frame(width: 34, height: 34)
                .background(fg.opacity(0.08))
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.subheadline.weight(.semibold))
                    .foregroundColor(fg)
                Text(subtitle)
                    .font(.caption)
                    .foregroundColor(fg.opacity(0.65))
            }
            Spacer()
            Image(systemName: "chevron.right")
                .font(.system(size: 12, weight: .light))
                .foregroundColor(fg.opacity(0.55))
        }
        .padding(12)
        .background(fg.opacity(0.045))
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

struct FeatureRequestView: View {
    @EnvironmentObject var settings: TeleprompterSettings
    @State private var ideaTitle: String = ""
    @State private var ideaNotes: String = ""
    @State private var submitted: Bool = false

    var body: some View {
        let fg = settings.primaryForeground
        let bg = settings.primaryBackground
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Feature Request")
                    .font(.largeTitle.weight(.bold))
                Text("Have an idea to make Teleprompter better? Send your request below or open an issue on GitHub.")
                    .font(.subheadline)
                    .foregroundColor(fg.opacity(0.7))

                TextField("Short title for your idea...", text: $ideaTitle)
                    .padding(12)
                    .background(fg.opacity(0.06))
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))

                TextField("Details (optional)...", text: $ideaNotes)
                    .padding(12)
                    .background(fg.opacity(0.06))
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))

                Button {
                    submitted = true
                    ideaTitle = ""
                    ideaNotes = ""
                } label: {
                    Text(submitted ? "Request Saved — Thank You!" : "Send Feature Request")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(fg)
                        .foregroundColor(bg)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
                .buttonStyle(.plain)

                if let url = URL(string: "https://github.com/muneebwanee") {
                    Link("Open GitHub (github.com/muneebwanee) ↗", destination: url)
                        .font(.caption.weight(.semibold))
                        .foregroundColor(fg)
                }
            }
            .foregroundColor(fg)
            .padding(24)
        }
        .background(bg.ignoresSafeArea())
        .navigationTitle("Feature Request")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct PrivacyPolicyView: View {
    @EnvironmentObject var settings: TeleprompterSettings
    var body: some View {
        let fg = settings.primaryForeground
        let bg = settings.primaryBackground
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Privacy Policy")
                    .font(.largeTitle.weight(.bold))
                Text("On-Device Privacy")
                    .font(.subheadline)
                    .foregroundColor(fg.opacity(0.65))

                Text("1. Local Script Storage")
                    .font(.headline)
                Text("All scripts, notes, recorded videos, and settings are saved directly on your iPhone or iPad. Nothing is uploaded to external servers.")
                    .foregroundColor(fg.opacity(0.78))

                Text("2. Camera & Voice Glide")
                    .font(.headline)
                Text("Camera previews, video recordings, video trimming, and Voice Glide run on your device.")
                    .foregroundColor(fg.opacity(0.78))

                Text("3. No Tracking")
                    .font(.headline)
                Text("Teleprompter contains no analytics, advertising, or background tracking.")
                    .foregroundColor(fg.opacity(0.78))
            }
            .foregroundColor(fg)
            .padding(24)
        }
        .background(bg.ignoresSafeArea())
        .navigationTitle("Privacy Policy")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct TermsOfServiceView: View {
    @EnvironmentObject var settings: TeleprompterSettings
    var body: some View {
        let fg = settings.primaryForeground
        let bg = settings.primaryBackground
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Terms of Service")
                    .font(.largeTitle.weight(.bold))

                Text("1. Your Content")
                    .font(.headline)
                Text("You retain full ownership of all scripts and video recordings created with Teleprompter.")
                    .foregroundColor(fg.opacity(0.78))

                Text("2. Local Backups")
                    .font(.headline)
                Text("Because Teleprompter works offline without cloud accounts, keep regular backups of your important scripts and saved videos.")
                    .foregroundColor(fg.opacity(0.78))

                Text("3. Open License")
                    .font(.headline)
                Text("Developed by muneebwanee (github.com/muneebwanee) and provided 'as is' without warranty of any kind.")
                    .foregroundColor(fg.opacity(0.78))
            }
            .foregroundColor(fg)
            .padding(24)
        }
        .background(bg.ignoresSafeArea())
        .navigationTitle("Terms of Service")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct AboutDeveloperView: View {
    @EnvironmentObject var settings: TeleprompterSettings
    var body: some View {
        let fg = settings.primaryForeground
        let bg = settings.primaryBackground
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                HStack(spacing: 16) {
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .fill(fg)
                        .frame(width: 60, height: 60)
                        .overlay(
                            Image(systemName: "text.viewfinder")
                                .font(.system(size: 28, weight: .light))
                                .foregroundColor(bg)
                        )
                    VStack(alignment: .leading, spacing: 4) {
                        Text("v0.0.1 Teleprompter")
                            .font(.title2.weight(.bold))
                            .foregroundColor(fg)
                        Text("Developed by muneebwanee")
                            .font(.subheadline.weight(.semibold))
                            .foregroundColor(fg.opacity(0.75))
                    }
                }

                Divider()

                Text("Developed by muneebwanee (github.com/muneebwanee)")
                    .font(.headline)
                    .foregroundColor(fg)

                Text("Minimalist iOS & iPadOS teleprompter with Voice Glide, Precision Settings, External Display, Livestream Connection, Remote Control, and native Home Screen Widgets.")
                    .foregroundColor(fg.opacity(0.72))

                if let url = URL(string: "https://github.com/muneebwanee") {
                    Link(destination: url) {
                        HStack {
                            Image(systemName: "link")
                                .font(.system(size: 14, weight: .light))
                            Text("github.com/muneebwanee")
                                .fontWeight(.semibold)
                            Spacer()
                            Image(systemName: "arrow.up.right")
                                .font(.system(size: 13, weight: .light))
                        }
                        .foregroundColor(fg)
                        .padding(16)
                        .liquidGlass(cornerRadius: 18, isHighlighted: true)
                    }
                }
            }
            .padding(24)
        }
        .background(bg.ignoresSafeArea())
        .navigationTitle("About")
        .navigationBarTitleDisplayMode(.inline)
    }
}
