import SwiftUI

struct VectorMotionArtView: View {
    @EnvironmentObject var settings: TeleprompterSettings
    var speedMultiplier: Double = 1.0

    var body: some View {
        Color.clear
    }
}
