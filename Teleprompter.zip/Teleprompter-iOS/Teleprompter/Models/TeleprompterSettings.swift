import SwiftUI

enum PrompterTheme: String, CaseIterable, Codable, Identifiable {
    case softInk = "Soft Ink"
    case warmPaper = "Warm Paper"

    var id: String { rawValue }

    static let warmPaperColor = Color(red: 245.0 / 255.0, green: 245.0 / 255.0, blue: 243.0 / 255.0)
    static let softInkColor   = Color(red: 34.0 / 255.0, green: 34.0 / 255.0, blue: 32.0 / 255.0)

    var subtitle: String {
        switch self {
        case .softInk: return "Low-Glare Dark Canvas"
        case .warmPaper: return "Daylight Reading Surface"
        }
    }

    func backgroundColor(isLight: Bool) -> Color {
        isLight ? Self.warmPaperColor : Self.softInkColor
    }

    func cardSurface(isLight: Bool) -> Color {
        isLight ? Self.softInkColor.opacity(0.045) : Self.warmPaperColor.opacity(0.055)
    }

    func primaryText(isLight: Bool) -> Color {
        isLight ? Self.softInkColor : Self.warmPaperColor
    }

    func secondaryText(isLight: Bool) -> Color {
        isLight ? Self.softInkColor.opacity(0.65) : Self.warmPaperColor.opacity(0.65)
    }

    func contrastText(isLight: Bool) -> Color {
        isLight ? Self.warmPaperColor : Self.softInkColor
    }

    var accentTint: Color {
        self == .warmPaper ? Self.softInkColor : Self.warmPaperColor
    }

    var accentGradient: LinearGradient {
        let c = accentTint
        return LinearGradient(colors: [c, c], startPoint: .topLeading, endPoint: .bottomTrailing)
    }
}

enum PrompterFontDesign: String, CaseIterable, Codable, Identifiable {
    case sans = "Clean Sans"
    case rounded = "Soft Rounded"
    case serif = "Book Serif"
    case mono = "Studio Mono"

    var id: String { rawValue }

    var swiftUIFontDesign: Font.Design {
        switch self {
        case .sans: return .default
        case .rounded: return .rounded
        case .serif: return .serif
        case .mono: return .monospaced
        }
    }
}

enum ScrollMode: String, CaseIterable, Codable, Identifiable {
    case continuous = "Smooth Speed"
    case voiceActivated = "Voice Glide"
    case voiceLevel = "Voice Loudness"
    case manual = "Manual Touch"

    var id: String { rawValue }

    var icon: String {
        switch self {
        case .continuous: return "speedometer"
        case .voiceActivated: return "waveform"
        case .voiceLevel: return "mic"
        case .manual: return "hand.draw"
        }
    }
}

struct LiquidGlassModifier: ViewModifier {
    @EnvironmentObject var settings: TeleprompterSettings
    var cornerRadius: CGFloat = 24
    var isHighlighted: Bool = false

    func body(content: Content) -> some View {
        let isLight = settings.isLightMode
        let inkOrPaper = settings.primaryForeground
        content
            .background(settings.theme.cardSurface(isLight: isLight))
            .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .stroke(
                        inkOrPaper.opacity(isHighlighted ? 0.38 : 0.14),
                        lineWidth: isHighlighted ? 1.5 : 1.0
                    )
            )
    }
}

extension View {
    func liquidGlass(cornerRadius: CGFloat = 24, isHighlighted: Bool = false) -> some View {
        modifier(LiquidGlassModifier(cornerRadius: cornerRadius, isHighlighted: isHighlighted))
    }
}

@MainActor
final class TeleprompterSettings: ObservableObject {
    @AppStorage("tp_fontSize") var fontSize: Double = 42.0
    @AppStorage("tp_lineSpacing") var lineSpacing: Double = 14.0
    @AppStorage("tp_sideMargin") var horizontalMargin: Double = 32.0
    @AppStorage("tp_scrollSpeed") var wordsPerMinute: Double = 145.0
    @AppStorage("tp_mirrorH") var mirrorHorizontal: Bool = false
    @AppStorage("tp_mirrorV") var mirrorVertical: Bool = false
    @AppStorage("tp_eyeLinePosition") var eyeLineVerticalRatio: Double = 0.28
    @AppStorage("tp_eyeLineHeight") var eyeLineBandHeight: Double = 84.0
    @AppStorage("tp_showEyeLine") var showEyeLineGuide: Bool = true
    @AppStorage("tp_dimUnread") var focusDimmingEnabled: Bool = true
    @AppStorage("tp_easyRead") var easyReadEnabled: Bool = false
    @AppStorage("tp_autoPauseTag") var autoWaitOnPauseTag: Bool = true
    @AppStorage("tp_loopScript") var loopScriptEnabled: Bool = false
    @AppStorage("tp_autoRewind") var autoRewindOnStop: Bool = true
    @AppStorage("tp_countdownSeconds") var countdownSeconds: Int = 3
    @AppStorage("tp_showCameraPiP") var showCameraPreview: Bool = true
    @AppStorage("tp_fullScreenCamera") var fullScreenCameraStage: Bool = false
    @AppStorage("tp_showTimecode") var showElapsedTimer: Bool = true
    @AppStorage("tp_showCuePills") var renderCueBadges: Bool = true
    @AppStorage("tp_overlayWidthRatio") var overlayWidthRatio: Double = 0.88
    @AppStorage("tp_overlayHeight") var overlayHeight: Double = 185.0
    @AppStorage("tp_overlayOffsetX") var overlayOffsetX: Double = 0.0
    @AppStorage("tp_overlayOffsetY") var overlayOffsetY: Double = 0.0
    @AppStorage("tp_videoFormat") var videoFormat: String = "4K • 60 fps"
    // Voice Glide
    @AppStorage("tp_voiceGlideEnabled") var voiceGlideEnabled: Bool = true
    @AppStorage("tp_voiceGlideSmoothing") var voiceGlideSmoothing: Double = 75.0
    @AppStorage("tp_voiceSilenceHold") var voiceSilenceHold: Double = 1.2
    @AppStorage("tp_voiceAutoResume") var voiceAutoResume: Bool = true
    @AppStorage("tp_voiceLanguage") var voiceLanguage: String = "English (US)"
    @AppStorage("tp_micSensitivity") var micSensitivity: Double = 80.0
    @AppStorage("tp_noiseGate") var noiseGateThreshold: Double = 22.0
    // Precision
    @AppStorage("tp_fineSpeedStep") var fineSpeedStep: Double = 0.5
    @AppStorage("tp_smoothRamp") var smoothRampSeconds: Double = 0.8
    @AppStorage("tp_lockSpeedToTime") var lockSpeedToTargetTime: Bool = false
    // External Display
    @AppStorage("tp_extDisplayMode") var externalDisplayMode: String = "Clean Script Only"
    @AppStorage("tp_extDisplayRes") var externalDisplayResolution: String = "1080p • 60 Hz"
    @AppStorage("tp_extMirrorX") var externalMirrorHorizontal: Bool = false
    @AppStorage("tp_extMirrorY") var externalMirrorVertical: Bool = false
    @AppStorage("tp_extOverscan") var externalOverscanMargin: Double = 0.0
    // Livestream
    @AppStorage("tp_streamProtocol") var livestreamProtocol: String = "RTMP / RTMPS"
    @AppStorage("tp_streamURL") var livestreamServerURL: String = "rtmp://a.rtmp.youtube.com/live2"
    @AppStorage("tp_streamKey") var livestreamKey: String = ""
    @AppStorage("tp_streamBitrate") var livestreamBitrateMbps: Double = 6.5
    @AppStorage("tp_streamSaveLocal") var livestreamSaveLocalCopy: Bool = true
    @AppStorage("tp_streamActive") var isLivestreaming: Bool = false
    // Remote Control
    @AppStorage("tp_remoteBluetooth") var bluetoothRemoteEnabled: Bool = true
    @AppStorage("tp_remotePedalMode") var footPedalMode: String = "Tap to Start / Stop"
    @AppStorage("tp_remoteSecondDevice") var secondDeviceRemoteEnabled: Bool = false
    @AppStorage("tp_keyPlayPause") var keyPlayPause: String = "Space"
    @AppStorage("tp_keyFaster") var keyFaster: String = "Up Arrow"
    @AppStorage("tp_keySlower") var keySlower: String = "Down Arrow"
    @AppStorage("tp_keyMirror") var keyMirror: String = "M Key"
    // Camera
    @AppStorage("tp_stabilization") var opticalStabilization: Bool = true
    @AppStorage("tp_exposureLock") var lockExposure: Bool = true
    @AppStorage("tp_isLightMode") var isLightMode: Bool = false
    @AppStorage("tp_theme") var selectedThemeRaw: String = PrompterTheme.softInk.rawValue
    @AppStorage("tp_fontDesign") var selectedFontRaw: String = PrompterFontDesign.sans.rawValue
    @AppStorage("tp_scrollMode") var scrollModeRaw: String = ScrollMode.continuous.rawValue

    var primaryForeground: Color {
        isLightMode ? PrompterTheme.softInkColor : PrompterTheme.warmPaperColor
    }

    var primaryBackground: Color {
        isLightMode ? PrompterTheme.warmPaperColor : PrompterTheme.softInkColor
    }

    var theme: PrompterTheme {
        get { isLightMode ? .warmPaper : .softInk }
        set {
            withAnimation(.spring(response: 0.32, dampingFraction: 0.82)) {
                isLightMode = (newValue == .warmPaper)
                selectedThemeRaw = newValue.rawValue
                objectWillChange.send()
            }
        }
    }

    func toggleAppearanceMode() {
        withAnimation(.spring(response: 0.32, dampingFraction: 0.82)) {
            isLightMode.toggle()
            selectedThemeRaw = isLightMode ? PrompterTheme.warmPaper.rawValue : PrompterTheme.softInk.rawValue
            objectWillChange.send()
        }
    }

    var fontDesign: PrompterFontDesign {
        get { PrompterFontDesign(rawValue: selectedFontRaw) ?? .sans }
        set {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
                selectedFontRaw = newValue.rawValue
                objectWillChange.send()
            }
        }
    }

    var scrollMode: ScrollMode {
        get { ScrollMode(rawValue: scrollModeRaw) ?? .continuous }
        set {
            withAnimation(.spring(response: 0.28, dampingFraction: 0.8)) {
                scrollModeRaw = newValue.rawValue
                objectWillChange.send()
            }
        }
    }

    func resetToDefaults() {
        withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
            fontSize = 42.0
            lineSpacing = 14.0
            horizontalMargin = 32.0
            wordsPerMinute = 145.0
            mirrorHorizontal = false
            mirrorVertical = false
            eyeLineVerticalRatio = 0.28
            eyeLineBandHeight = 84.0
            showEyeLineGuide = true
            focusDimmingEnabled = true
            easyReadEnabled = false
            autoWaitOnPauseTag = true
            loopScriptEnabled = false
            autoRewindOnStop = true
            countdownSeconds = 3
            showCameraPreview = true
            fullScreenCameraStage = false
            overlayWidthRatio = 0.88
            overlayHeight = 185.0
            overlayOffsetX = 0.0
            overlayOffsetY = 0.0
            videoFormat = "4K • 60 fps"
            voiceGlideEnabled = true
            voiceGlideSmoothing = 75.0
            voiceSilenceHold = 1.2
            voiceAutoResume = true
            micSensitivity = 80.0
            noiseGateThreshold = 22.0
            fineSpeedStep = 0.5
            smoothRampSeconds = 0.8
            lockSpeedToTargetTime = false
            isLightMode = false
            selectedThemeRaw = PrompterTheme.softInk.rawValue
            selectedFontRaw = PrompterFontDesign.sans.rawValue
            scrollModeRaw = ScrollMode.continuous.rawValue
        }
    }
}
