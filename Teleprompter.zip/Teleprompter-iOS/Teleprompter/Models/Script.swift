import Foundation
import SwiftUI

struct CueMarker: Identifiable, Hashable {
    let id = UUID()
    let label: String
    let lineIndex: Int
}

struct ScriptItem: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var title: String
    var category: String
    var content: String
    var targetWPM: Int
    var lastModified: Date
    var isPinned: Bool
    var notes: String

    var wordCount: Int {
        content
            .components(separatedBy: .whitespacesAndNewlines)
            .filter { !$0.isEmpty && !$0.hasPrefix("[") }
            .count
    }

    var estimatedDurationSeconds: Int {
        guard targetWPM > 0 else { return 0 }
        let baseSeconds = Int((Double(wordCount) / Double(targetWPM)) * 60.0)
        let pauseCount = content.components(separatedBy: "[PAUSE]").count - 1
        return baseSeconds + (max(0, pauseCount) * 2)
    }

    var formattedDuration: String {
        let total = estimatedDurationSeconds
        let mins = total / 60
        let secs = total % 60
        return String(format: "%d:%02d", mins, secs)
    }

    var paragraphs: [String] {
        content
            .replacingOccurrences(of: "\r\n", with: "\n")
            .components(separatedBy: "\n")
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
    }

    mutating func formatShortLines() {
        let raw = content.replacingOccurrences(of: "\n\n", with: "\n")
        let sentences = raw
            .replacingOccurrences(of: ". ", with: ".\n")
            .replacingOccurrences(of: "? ", with: "?\n")
            .replacingOccurrences(of: "! ", with: "!\n")
        content = sentences
        lastModified = Date()
    }
}

@MainActor
final class ScriptStore: ObservableObject {
    @Published var scripts: [ScriptItem] = [] {
        didSet { save() }
    }
    @Published var selectedScriptID: UUID?

    private let storageKey = "teleprompter_scripts_v2"

    init() {
        load()
        if scripts.isEmpty {
            scripts = Self.sampleScripts
            selectedScriptID = scripts.first?.id
        }
    }

    var selectedScript: ScriptItem? {
        get {
            if let id = selectedScriptID, let found = scripts.first(where: { $0.id == id }) {
                return found
            }
            return scripts.first
        }
        set {
            guard let updated = newValue,
                  let idx = scripts.firstIndex(where: { $0.id == updated.id }) else { return }
            scripts[idx] = updated
        }
    }

    func createScript(title: String = "New Script", category: String = "Keynote") -> ScriptItem {
        let newScript = ScriptItem(
            title: title,
            category: category,
            content: "Welcome to Teleprompter.\n\n[PAUSE]\n\nType or paste your script here. Use [PAUSE] for breath cues and [EMPHASIS] to highlight key talking points while you record.",
            targetWPM: 140,
            lastModified: Date(),
            isPinned: false,
            notes: "Keep your eyes near the top camera lens."
        )
        scripts.insert(newScript, at: 0)
        selectedScriptID = newScript.id
        return newScript
    }

    func deleteScript(id: UUID) {
        scripts.removeAll { $0.id == id }
        if selectedScriptID == id {
            selectedScriptID = scripts.first?.id
        }
    }

    func duplicateScript(_ script: ScriptItem) {
        var copy = script
        copy.id = UUID()
        copy.title = "\(script.title) (Copy)"
        copy.lastModified = Date()
        scripts.insert(copy, at: 0)
        selectedScriptID = copy.id
    }

    private func save() {
        if let data = try? JSONEncoder().encode(scripts) {
            UserDefaults.standard.set(data, forKey: storageKey)
        }
    }

    private func load() {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let decoded = try? JSONDecoder().decode([ScriptItem].self, from: data) else { return }
        scripts = decoded
        selectedScriptID = scripts.first?.id
    }

    static let sampleScripts: [ScriptItem] = [
        ScriptItem(
            title: "Example 1: Welcome & 1-Min App Tour",
            category: "Keynote",
            content: """
            Welcome to Teleprompter! This quick example shows how everything works.
            [PAUSE]
            Keep your eyes inside the reading band between the two arrows so you maintain natural eye contact with your audience.
            [EMPHASIS] Want to switch themes? Tap the Moon or Sun icon at the top to switch between Soft Ink (#222220) and Warm Paper (#F5F5F3).
            [PAUSE]
            Tap any line to jump straight to it, or use the bottom bar to switch between Smooth Speed, Voice Glide, and Manual Touch.
            """,
            targetWPM: 140,
            lastModified: Date(),
            isPinned: true,
            notes: "Start here to explore live reading, eye-line height, and theme switching."
        ),
        ScriptItem(
            title: "Example 2: Camera & Movable Script Box",
            category: "Video",
            content: """
            Tap the Camera button to record yourself in 4K while reading your script.
            [PAUSE]
            While recording, drag the top handle of the script box to position it right next to your Front or Back camera lens.
            [EMPHASIS] Tap the Area button on the script box to adjust its Width, Height, See-Through Opacity, and Speed live while filming.
            [PAUSE]
            When you stop recording, the Video Trimmer opens automatically so you can trim the start and end and save to Photos or Files.
            """,
            targetWPM: 150,
            lastModified: Date().addingTimeInterval(-1800),
            isPinned: false,
            notes: "Try dragging and resizing the script box while recording."
        ),
        ScriptItem(
            title: "Example 3: Voice Glide & Easy Read Demo",
            category: "Podcast",
            content: """
            This example demonstrates Voice Glide and Easy Read mode.
            [PAUSE]
            When Voice Glide is selected, your script glides smoothly at your speaking pace and waits automatically when you pause.
            [EMPHASIS] Turn on Easy Read in Settings to bold the start of words so your eyes scan each line effortlessly.
            [PAUSE]
            You can customize Glide Smoothing, Mic Sensitivity, and Pause Hold Time inside Settings under Voice Glide.
            """,
            targetWPM: 145,
            lastModified: Date().addingTimeInterval(-3600 * 4),
            isPinned: false,
            notes: "Great for natural, unscripted-sounding conversations."
        ),
        ScriptItem(
            title: "Example 4: 60-Second Short Video (9:16)",
            category: "Video",
            content: """
            Here is a 60-second vertical video template for Reels, Shorts, or TikTok.
            [PAUSE]
            Start with a clear hook in the first three seconds: Today I am sharing three simple habits for clear, confident speaking on camera.
            [EMPHASIS] Habit one: keep your script box right near the top camera lens so you never look away from your viewer.
            [PAUSE]
            Habit two: tap Short Lines in the editor so each sentence fits cleanly on a single row.
            """,
            targetWPM: 160,
            lastModified: Date().addingTimeInterval(-3600 * 12),
            isPinned: false,
            notes: "Use Front Camera and Short Lines formatting."
        ),
        ScriptItem(
            title: "Example 5: Mirror Glass & External Display",
            category: "Update",
            content: """
            Using a physical teleprompter mirror hood or an external HDMI / AirPlay display?
            [PAUSE]
            Tap Flip L-R on the reading screen or open Settings -> External Display.
            [EMPHASIS] Flip L-R mirrors the text horizontally so it reflects the right way up on beam-splitter glass in front of your lens.
            [PAUSE]
            You can also pair a Bluetooth keyboard, clicker, or foot pedal in Remote Control settings.
            """,
            targetWPM: 135,
            lastModified: Date().addingTimeInterval(-3600 * 24),
            isPinned: false,
            notes: "Demonstrates mirror glass flip and external screen output."
        )
    ]
}
