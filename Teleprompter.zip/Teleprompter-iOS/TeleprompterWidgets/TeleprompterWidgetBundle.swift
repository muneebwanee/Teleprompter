import WidgetKit
import SwiftUI

struct TeleprompterWidgetEntry: TimelineEntry {
    let date: Date
    let scriptTitle: String
    let scriptExcerpt: String
    let wordCount: Int
    let duration: String
    let wpm: Int
}

struct TeleprompterWidgetProvider: TimelineProvider {
    func placeholder(in context: Context) -> TeleprompterWidgetEntry {
        loadSharedEntry()
    }

    func getSnapshot(in context: Context, completion: @escaping (TeleprompterWidgetEntry) -> Void) {
        completion(loadSharedEntry())
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<TeleprompterWidgetEntry>) -> Void) {
        let entry = loadSharedEntry()
        completion(Timeline(entries: [entry], policy: .after(Date().addingTimeInterval(900))))
    }

    private func loadSharedEntry() -> TeleprompterWidgetEntry {
        let defaults = UserDefaults(suiteName: "group.com.muneebwanee.teleprompter") ?? .standard
        let title = defaults.string(forKey: "widget_script_title") ?? "Morning Talk"
        let excerpt = defaults.string(forKey: "widget_script_excerpt") ?? "Good morning everyone, and welcome. Every great product begins with a simple idea."
        let words = defaults.integer(forKey: "widget_word_count")
        let dur = defaults.string(forKey: "widget_duration") ?? "1:00"
        let speed = defaults.integer(forKey: "widget_wpm")
        return TeleprompterWidgetEntry(
            date: Date(),
            scriptTitle: title,
            scriptExcerpt: excerpt,
            wordCount: words > 0 ? words : 140,
            duration: dur,
            wpm: speed > 0 ? speed : 145
        )
    }
}

private let warmPaper = Color(red: 245.0 / 255.0, green: 245.0 / 255.0, blue: 243.0 / 255.0)
private let softInk   = Color(red: 34.0 / 255.0, green: 34.0 / 255.0, blue: 32.0 / 255.0)

extension View {
    @ViewBuilder
    func widgetSurface(background: Color) -> some View {
        if #available(iOSApplicationExtension 17.0, *) {
            self.containerBackground(for: .widget) {
                background
            }
        } else {
            self.background(background)
        }
    }
}

// 1. Next Script Card Widget (Small, Medium & Lock Screen Rectangular)
struct QuickLaunchWidgetView: View {
    @Environment(\.widgetFamily) var family
    var entry: TeleprompterWidgetEntry

    var body: some View {
        if family == .accessoryRectangular {
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 4) {
                    Image(systemName: "doc.text")
                    Text(entry.scriptTitle)
                        .font(.caption.weight(.bold))
                        .lineLimit(1)
                }
                Text("\(entry.wordCount) words • \(entry.duration) • \(entry.wpm) WPM")
                    .font(.caption2)
                    .opacity(0.8)
            }
            .widgetURL(URL(string: "teleprompter://read"))
        } else {
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 6) {
                    Image(systemName: "doc.text")
                        .font(.system(size: 12, weight: .light))
                        .foregroundColor(warmPaper)
                    Text("NEXT SCRIPT")
                        .font(.system(size: 9, weight: .semibold))
                        .tracking(0.8)
                        .foregroundColor(warmPaper.opacity(0.65))
                    Spacer()
                    Text(entry.duration)
                        .font(.system(size: 10, weight: .semibold, design: .monospaced))
                        .padding(.horizontal, 7)
                        .padding(.vertical, 2)
                        .background(warmPaper.opacity(0.12))
                        .foregroundColor(warmPaper)
                        .clipShape(Capsule())
                }

                Text(entry.scriptTitle)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(warmPaper)
                    .lineLimit(2)

                Spacer()

                HStack {
                    Text("\(entry.wordCount) words • \(entry.wpm) WPM")
                        .font(.caption2)
                        .foregroundColor(warmPaper.opacity(0.62))
                    Spacer()
                    HStack(spacing: 4) {
                        Image(systemName: "play.fill")
                            .font(.system(size: 8))
                        Text("Read")
                            .font(.caption2.weight(.semibold))
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(warmPaper)
                    .foregroundColor(softInk)
                    .clipShape(Capsule())
                }
            }
            .padding(14)
            .widgetSurface(background: softInk)
            .widgetURL(URL(string: "teleprompter://read"))
        }
    }
}

// 2. One-Tap Studio Actions Widget (Small & Medium — Warm Paper Daylight Surface)
struct CameraRigWidgetView: View {
    var entry: TeleprompterWidgetEntry

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Image(systemName: "camera")
                    .font(.system(size: 12, weight: .light))
                    .foregroundColor(softInk)
                Text("QUICK RECORD")
                    .font(.system(size: 9, weight: .semibold))
                    .tracking(0.8)
                    .foregroundColor(softInk.opacity(0.65))
                Spacer()
                Text("4K 60")
                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                    .foregroundColor(softInk.opacity(0.65))
            }

            Text("Camera & Voice Glide")
                .font(.system(size: 15, weight: .semibold))
                .foregroundColor(softInk)

            Spacer()

            HStack(spacing: 6) {
                Link(destination: URL(string: "teleprompter://camera?lens=front")!) {
                    HStack(spacing: 4) {
                        Image(systemName: "person")
                            .font(.system(size: 9, weight: .light))
                        Text("Front")
                            .font(.caption2.weight(.semibold))
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(softInk)
                    .foregroundColor(warmPaper)
                    .clipShape(Capsule())
                }
                Link(destination: URL(string: "teleprompter://camera?lens=back")!) {
                    HStack(spacing: 4) {
                        Image(systemName: "camera")
                            .font(.system(size: 9, weight: .light))
                        Text("Back")
                            .font(.caption2.weight(.semibold))
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(softInk.opacity(0.09))
                    .foregroundColor(softInk)
                    .clipShape(Capsule())
                }
                Link(destination: URL(string: "teleprompter://voiceglide")!) {
                    HStack(spacing: 4) {
                        Image(systemName: "waveform")
                            .font(.system(size: 9, weight: .light))
                        Text("Voice Glide")
                            .font(.caption2.weight(.semibold))
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(softInk.opacity(0.09))
                    .foregroundColor(softInk)
                    .clipShape(Capsule())
                }
            }
        }
        .padding(14)
        .widgetSurface(background: warmPaper)
        .widgetURL(URL(string: "teleprompter://camera"))
    }
}

// 3. Speaking Speed & Time Ring Widget (Small, Medium & Lock Screen Circular)
struct PaceRingsWidgetView: View {
    @Environment(\.widgetFamily) var family
    var entry: TeleprompterWidgetEntry

    var body: some View {
        if family == .accessoryCircular {
            ZStack {
                Circle()
                    .stroke(lineWidth: 3)
                    .opacity(0.25)
                Circle()
                    .trim(from: 0, to: 0.72)
                    .stroke(style: StrokeStyle(lineWidth: 3, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                VStack(spacing: 0) {
                    Text("\(entry.wpm)")
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                    Text("WPM")
                        .font(.system(size: 7, weight: .semibold))
                }
            }
            .widgetURL(URL(string: "teleprompter://read"))
        } else {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Image(systemName: "speedometer")
                        .font(.system(size: 12, weight: .light))
                        .foregroundColor(warmPaper)
                    Text("READING SPEED")
                        .font(.system(size: 9, weight: .semibold))
                        .tracking(0.8)
                        .foregroundColor(warmPaper.opacity(0.65))
                    Spacer()
                }
                HStack(spacing: 12) {
                    ZStack {
                        Circle()
                            .stroke(warmPaper.opacity(0.14), lineWidth: 3.5)
                            .frame(width: 44, height: 44)
                        Circle()
                            .trim(from: 0, to: 0.72)
                            .stroke(warmPaper, style: StrokeStyle(lineWidth: 3.5, lineCap: .round))
                            .frame(width: 44, height: 44)
                            .rotationEffect(.degrees(-90))
                        Text("\(entry.wpm)")
                            .font(.system(size: 12, weight: .bold, design: .rounded))
                            .foregroundColor(warmPaper)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text("\(entry.wpm) WPM")
                            .font(.caption.weight(.semibold))
                            .foregroundColor(warmPaper)
                        Text("Time: \(entry.duration)")
                            .font(.caption2)
                            .foregroundColor(warmPaper.opacity(0.65))
                    }
                }
                Spacer()
                Text("Tap to Start Reading ▶")
                    .font(.caption2.weight(.semibold))
                    .foregroundColor(warmPaper)
            }
            .padding(14)
            .widgetSurface(background: softInk)
            .widgetURL(URL(string: "teleprompter://read"))
        }
    }
}

// 4. Large Eye-Line Teleprompter Preview Widget (Large 4x4 for iPhone & iPad Home Screen)
struct LiveReaderWidgetView: View {
    var entry: TeleprompterWidgetEntry

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: "text.viewfinder")
                    .font(.system(size: 13, weight: .light))
                    .foregroundColor(warmPaper)
                Text(entry.scriptTitle)
                    .font(.subheadline.weight(.semibold))
                    .foregroundColor(warmPaper)
                Spacer()
                Text("\(entry.wpm) WPM • \(entry.duration)")
                    .font(.system(size: 11, weight: .medium, design: .monospaced))
                    .foregroundColor(warmPaper.opacity(0.68))
            }

            // Minimalist Eye-Line Reading Band Preview
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 8) {
                    Text("▶")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundColor(warmPaper)
                    Text(entry.scriptExcerpt)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(warmPaper)
                        .lineSpacing(5)
                        .lineLimit(4)
                    Spacer(minLength: 0)
                    Text("◀")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundColor(warmPaper)
                }
                .padding(12)
                .background(warmPaper.opacity(0.08))
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .stroke(warmPaper.opacity(0.22), lineWidth: 1)
                )
            }

            Spacer()

            HStack {
                Text("\(entry.wordCount) words")
                    .font(.caption2)
                    .foregroundColor(warmPaper.opacity(0.62))
                Spacer()
                HStack(spacing: 8) {
                    Link(destination: URL(string: "teleprompter://new")!) {
                        Text("+ New Script")
                            .font(.caption2.weight(.semibold))
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(warmPaper.opacity(0.12))
                            .foregroundColor(warmPaper)
                            .clipShape(Capsule())
                    }
                    Link(destination: URL(string: "teleprompter://voiceglide")!) {
                        Text("Voice Glide")
                            .font(.caption2.weight(.semibold))
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(warmPaper.opacity(0.12))
                            .foregroundColor(warmPaper)
                            .clipShape(Capsule())
                    }
                    Link(destination: URL(string: "teleprompter://read")!) {
                        Text("Read Now ▶")
                            .font(.caption2.weight(.semibold))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(warmPaper)
                            .foregroundColor(softInk)
                            .clipShape(Capsule())
                    }
                }
            }
        }
        .padding(16)
        .widgetSurface(background: softInk)
        .widgetURL(URL(string: "teleprompter://read"))
    }
}

struct TeleprompterQuickLaunchWidget: Widget {
    let kind: String = "TeleprompterQuickLaunchWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: TeleprompterWidgetProvider()) { entry in
            QuickLaunchWidgetView(entry: entry)
        }
        .configurationDisplayName("Next Script Reader")
        .description("See your pinned script, word count, and reading time with a one-tap Read button.")
        .supportedFamilies([.systemSmall, .systemMedium, .accessoryRectangular])
    }
}

struct TeleprompterCameraRigWidget: Widget {
    let kind: String = "TeleprompterCameraRigWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: TeleprompterWidgetProvider()) { entry in
            CameraRigWidgetView(entry: entry)
        }
        .configurationDisplayName("Camera & Voice Glide")
        .description("Start Front Camera, Back Camera, or Voice Glide in one tap from your Home Screen.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}

struct TeleprompterPaceRingsWidget: Widget {
    let kind: String = "TeleprompterPaceRingsWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: TeleprompterWidgetProvider()) { entry in
            PaceRingsWidgetView(entry: entry)
        }
        .configurationDisplayName("Reading Speed Ring")
        .description("Track your reading speed in WPM and jump straight into your script.")
        .supportedFamilies([.systemSmall, .systemMedium, .accessoryCircular])
    }
}

struct TeleprompterLiveReaderWidget: Widget {
    let kind: String = "TeleprompterLiveReaderWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: TeleprompterWidgetProvider()) { entry in
            LiveReaderWidgetView(entry: entry)
        }
        .configurationDisplayName("Eye-Line Script Preview")
        .description("Preview your opening lines inside an eye-line frame and start reading or Voice Glide.")
        .supportedFamilies([.systemLarge])
    }
}

@main
struct TeleprompterWidgetBundle: WidgetBundle {
    var body: some Widget {
        TeleprompterQuickLaunchWidget()
        TeleprompterCameraRigWidget()
        TeleprompterPaceRingsWidget()
        TeleprompterLiveReaderWidget()
    }
}
